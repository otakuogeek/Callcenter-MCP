#!/bin/bash

echo "🏥 SISTEMA COMPLETO DE CITAS MÉDICAS - TEST INTEGRAL"
echo "====================================================="
echo ""

MCP_URL="https://biosanarcall.site/mcp/"

echo "📊 ESTADO DEL SISTEMA"
echo "--------------------"
echo "✅ Servidor MCP: $MCP_URL"
echo "✅ Total de herramientas: 5"
echo ""

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "1️⃣  HERRAMIENTAS DE EPS Y REGISTRO DE PACIENTES"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

echo ""
echo "📋 1.1 - Listar EPS Activas:"
curl -s -X POST "$MCP_URL" \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"listActiveEPS","arguments":{}}}' | \
  jq -r '.result.content[0].text | fromjson | 
    "  ✅ Total: " + (.count | tostring) + " EPS activas\n  🏥 Ejemplo: " + .eps_list[0].name + " (ID: " + (.eps_list[0].id | tostring) + ")"'

echo ""
echo "👤 1.2 - Registrar Nuevo Paciente:"
RANDOM_NUM=$((50000 + RANDOM % 50000))
PATIENT_RESPONSE=$(curl -s -X POST "$MCP_URL" \
  -H "Content-Type: application/json" \
  -d "{
    \"jsonrpc\":\"2.0\",
    \"id\":2,
    \"method\":\"tools/call\",
    \"params\":{
      \"name\":\"registerPatientSimple\",
      \"arguments\":{
        \"document\":\"TEST$RANDOM_NUM\",
        \"name\":\"Paciente Test Citas MCP\",
        \"phone\":\"311$RANDOM_NUM\",
        \"insurance_eps_id\":14,
        \"notes\":\"Test completo del sistema de citas\"
      }
    }
  }")

PATIENT_ID=$(echo "$PATIENT_RESPONSE" | jq -r '.result.content[0].text | fromjson | .patient_id')
echo "$PATIENT_RESPONSE" | jq -r '.result.content[0].text | fromjson | 
  "  ✅ Paciente registrado\n  🆔 ID: " + (.patient_id | tostring) + "\n  👤 Nombre: " + .patient.name + "\n  🏥 EPS: " + .patient.eps'

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "2️⃣  SISTEMA DE GESTIÓN DE CITAS MÉDICAS"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

echo ""
echo "📅 2.1 - Consultar Citas Disponibles (15 de Octubre):"
AVAIL_RESPONSE=$(curl -s -X POST "$MCP_URL" \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","id":3,"method":"tools/call","params":{"name":"getAvailableAppointments","arguments":{"date":"2025-10-15"}}}')

echo "$AVAIL_RESPONSE" | jq -r '.result.content[0].text | fromjson | 
  if .count > 0 then
    "  ✅ Disponibilidades encontradas: " + (.count | tostring) + "\n\n" +
    (.available_appointments[] | 
      "  📍 " + .location.name + "\n" +
      "  🩺 " + .specialty.name + "\n" +
      "  👨‍⚕️ " + .doctor.name + "\n" +
      "  🕐 " + .time_range + " (" + (.duration_minutes | tostring) + " minutos)\n" +
      "  💺 Cupos disponibles: " + (.slots_available | tostring) + "/" + (.quota | tostring) + "\n" +
      "  🔑 IDs: availability=" + (.availability_id | tostring) + ", distribution=" + (.distribution_id | tostring)
    )
  else
    "  ❌ No hay citas disponibles para esta fecha"
  end'

# Extraer availability_id para el siguiente test
AVAILABILITY_ID=$(echo "$AVAIL_RESPONSE" | jq -r '.result.content[0].text | fromjson | .available_appointments[0].availability_id')

if [ "$AVAILABILITY_ID" != "null" ] && [ "$AVAILABILITY_ID" != "" ]; then
  echo ""
  echo "🗓️ 2.2 - Agendar Cita para el Paciente:"
  SCHEDULE_RESPONSE=$(curl -s -X POST "$MCP_URL" \
    -H "Content-Type: application/json" \
    -d "{
      \"jsonrpc\":\"2.0\",
      \"id\":4,
      \"method\":\"tools/call\",
      \"params\":{
        \"name\":\"scheduleAppointment\",
        \"arguments\":{
          \"patient_id\":$PATIENT_ID,
          \"availability_id\":$AVAILABILITY_ID,
          \"scheduled_date\":\"2025-10-15 09:00:00\",
          \"appointment_type\":\"Presencial\",
          \"reason\":\"Consulta general - Test MCP\",
          \"notes\":\"Cita agendada automáticamente desde MCP\",
          \"priority_level\":\"Normal\"
        }
      }
    }")
  
  APPOINTMENT_ID=$(echo "$SCHEDULE_RESPONSE" | jq -r '.result.content[0].text | fromjson | .appointment_id')
  
  echo "$SCHEDULE_RESPONSE" | jq -r '.result.content[0].text | fromjson | 
    if .success then 
      "  ✅ Cita agendada exitosamente\n" +
      "  🆔 ID Cita: " + (.appointment_id | tostring) + "\n" +
      "  👤 Paciente: " + .appointment.patient.name + "\n" +
      "  📅 Fecha: " + .appointment.scheduled_at + "\n" +
      "  👨‍⚕️ Doctor: " + .appointment.doctor.name + "\n" +
      "  🩺 Especialidad: " + .appointment.specialty.name + "\n" +
      "  📍 Sede: " + .appointment.location.name + "\n" +
      "  ⏱️ Duración: " + (.appointment.duration_minutes | tostring) + " minutos\n" +
      "  💺 Cupos: " + (.availability_info.assigned | tostring) + "/" + (.availability_info.quota | tostring) + 
      " (Restantes: " + (.availability_info.remaining | tostring) + ")"
    else 
      "  ❌ Error: " + .error
    end'
  
  echo ""
  echo "🔍 2.3 - Consultar Citas del Paciente:"
  curl -s -X POST "$MCP_URL" \
    -H "Content-Type: application/json" \
    -d "{
      \"jsonrpc\":\"2.0\",
      \"id\":5,
      \"method\":\"tools/call\",
      \"params\":{
        \"name\":\"getPatientAppointments\",
        \"arguments\":{
          \"patient_id\":$PATIENT_ID
        }
      }
    }" | jq -r '.result.content[0].text | fromjson | 
    "  📊 Total de citas: " + (.count | tostring) + "\n" +
    "  📅 Próximas: " + (.summary.upcoming | tostring) + "\n" +
    "  📜 Pasadas: " + (.summary.past | tostring) + "\n" +
    "  ✅ Confirmadas: " + (.summary.by_status.confirmada | tostring) + "\n\n" +
    "  🗓️ PRÓXIMAS CITAS:\n" +
    (.upcoming_appointments[] | 
      "    • " + .scheduled_at + " - " + .doctor.name + 
      " (" + .specialty.name + ") - " + .status
    )'
else
  echo ""
  echo "⚠️ No hay disponibilidades para agendar citas en esta fecha"
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📊 RESUMEN DEL SISTEMA"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

echo ""
echo "🛠️ HERRAMIENTAS DISPONIBLES:"
curl -s -X POST "$MCP_URL" \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","id":6,"method":"tools/list"}' | \
  jq -r '.result.tools[] | "  ✅ " + .name + "\n     📝 " + .description'

echo ""
echo "📈 ESTADÍSTICAS DE BASE DE DATOS:"
mysql -u biosanar_user -p'/6Tx0eXqFQONTFuoc7aqPicNlPhmuINU' biosanar -e "
SELECT 
  'Pacientes Activos' as tipo, COUNT(*) as total FROM patients WHERE status = 'Activo'
UNION ALL
SELECT 'EPS Activas', COUNT(*) FROM eps WHERE status = 'active'
UNION ALL
SELECT 'Citas Hoy', COUNT(*) FROM appointments WHERE DATE(scheduled_at) = CURDATE()
UNION ALL
SELECT 'Citas Confirmadas', COUNT(*) FROM appointments WHERE status = 'Confirmada' AND scheduled_at >= NOW()
UNION ALL
SELECT 'Disponibilidades Activas', COUNT(*) FROM availabilities WHERE status = 'Activa' AND date >= CURDATE()
" 2>/dev/null | tail -n +2 | awk '{print "  📊 " $1 " " $2 ": " $3}'

echo ""
echo "🎯 FLUJO COMPLETO VERIFICADO:"
echo "  1. ✅ Consultar EPS disponibles"
echo "  2. ✅ Registrar nuevo paciente con EPS"
echo "  3. ✅ Consultar citas disponibles por fecha"
echo "  4. ✅ Agendar cita para el paciente"
echo "  5. ✅ Verificar citas del paciente"
echo ""
echo "🎉 SISTEMA COMPLETAMENTE FUNCIONAL"
echo ""
