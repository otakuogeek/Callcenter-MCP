#!/bin/bash

# ============================================================================
# TEST: LISTA DE ESPERA CON ENFOQUE EN ESPECIALIDAD
# ============================================================================
# Propósito: Verificar que el sistema agregue a lista de espera enfocándose
# en la especialidad y datos del paciente, sin importar el doctor específico
# ============================================================================

API_URL="https://biosanarcall.site/mcp/"
PATIENT_ID=1042  # Dey Alberto Bastidas (paciente activo de prueba)

# Colores para output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}PRUEBA: LISTA DE ESPERA - ENFOQUE ESPECIALIDAD${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# ============================================================================
# TEST 1: Obtener disponibilidad con información de waiting_list_count
# ============================================================================
echo -e "${YELLOW}TEST 1: Consultar disponibilidad (debe mostrar waiting_list_count)${NC}"

RESPONSE=$(curl -s -X POST "$API_URL" \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 1,
    "method": "tools/call",
    "params": {
      "name": "getAvailableAppointments",
      "arguments": {
        "specialty_id": 10,
        "limit": 3
      }
    }
  }')

echo "$RESPONSE" | jq -r '.result.content[] | select(.text != null) | .text' | jq '.' 2>/dev/null

# Extraer un availability_id de la respuesta
AVAILABILITY_ID=$(echo "$RESPONSE" | jq -r '.result.content[] | select(.text != null) | .text' | jq -r '.available_appointments[0].availability_id' 2>/dev/null)
SPECIALTY_NAME=$(echo "$RESPONSE" | jq -r '.result.content[] | select(.text != null) | .text' | jq -r '.available_appointments[0].specialty.name' 2>/dev/null)
SLOTS=$(echo "$RESPONSE" | jq -r '.result.content[] | select(.text != null) | .text' | jq -r '.available_appointments[0].slots_available' 2>/dev/null)
WAITING_COUNT=$(echo "$RESPONSE" | jq -r '.result.content[] | select(.text != null) | .text' | jq -r '.available_appointments[0].waiting_list_count' 2>/dev/null)

if [ ! -z "$AVAILABILITY_ID" ] && [ "$AVAILABILITY_ID" != "null" ]; then
    echo -e "${GREEN}✓ TEST 1 PASADO${NC}"
    echo "  - Availability ID: $AVAILABILITY_ID"
    echo "  - Especialidad: $SPECIALTY_NAME"
    echo "  - Slots disponibles: $SLOTS"
    echo "  - En lista de espera: $WAITING_COUNT"
else
    echo -e "${RED}✗ TEST 1 FALLIDO: No se pudo obtener availability_id${NC}"
    exit 1
fi

echo ""
sleep 2

# ============================================================================
# TEST 2: Intentar agendar en una fecha SIN cupos (debe ir a lista de espera)
# ============================================================================
echo -e "${YELLOW}TEST 2: Agendar cuando NO hay cupos (debe agregarse a lista de espera)${NC}"

# Primero, buscar una availability SIN cupos
RESPONSE_NO_SLOTS=$(curl -s -X POST "$API_URL" \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 2,
    "method": "tools/call",
    "params": {
      "name": "getAvailableAppointments",
      "arguments": {
        "specialty_id": 10,
        "limit": 50
      }
    }
  }')

# Buscar una agenda sin cupos
FULL_AVAILABILITY_ID=$(echo "$RESPONSE_NO_SLOTS" | jq -r '.result.content[] | select(.text != null) | .text' | jq -r '.available_appointments[] | select(.slots_available == "0") | .availability_id' 2>/dev/null | head -1)

if [ -z "$FULL_AVAILABILITY_ID" ] || [ "$FULL_AVAILABILITY_ID" == "null" ]; then
    echo -e "${YELLOW}⚠ No se encontró una agenda sin cupos. Usando la primera disponible para simular.${NC}"
    FULL_AVAILABILITY_ID=$AVAILABILITY_ID
fi

echo "  - Intentando agendar en availability_id: $FULL_AVAILABILITY_ID"

SCHEDULE_RESPONSE=$(curl -s -X POST "$API_URL" \
  -H "Content-Type: application/json" \
  -d "{
    \"jsonrpc\": \"2.0\",
    \"id\": 3,
    \"method\": \"tools/call\",
    \"params\": {
      \"name\": \"scheduleAppointment\",
      \"arguments\": {
        \"patient_id\": $PATIENT_ID,
        \"availability_id\": $FULL_AVAILABILITY_ID,
        \"scheduled_date\": \"2025-10-10 09:00:00\",
        \"appointment_type\": \"Presencial\",
        \"reason\": \"Consulta de prueba para lista de espera - enfoque especialidad\",
        \"priority_level\": \"Alta\"
      }
    }
  }")

echo "$SCHEDULE_RESPONSE" | jq -r '.result.content[] | select(.text != null) | .text' | jq '.' 2>/dev/null

IS_WAITING_LIST=$(echo "$SCHEDULE_RESPONSE" | jq -r '.result.content[] | select(.text != null) | .text' | jq -r '.waiting_list' 2>/dev/null)
WAITING_LIST_ID=$(echo "$SCHEDULE_RESPONSE" | jq -r '.result.content[] | select(.text != null) | .text' | jq -r '.waiting_list_id' 2>/dev/null)
QUEUE_POSITION=$(echo "$SCHEDULE_RESPONSE" | jq -r '.result.content[] | select(.text != null) | .text' | jq -r '.queue_position' 2>/dev/null)
TOTAL_WAITING=$(echo "$SCHEDULE_RESPONSE" | jq -r '.result.content[] | select(.text != null) | .text' | jq -r '.total_waiting_specialty' 2>/dev/null)
SPECIALTY_RETURNED=$(echo "$SCHEDULE_RESPONSE" | jq -r '.result.content[] | select(.text != null) | .text' | jq -r '.requested_for.specialty.name' 2>/dev/null)

if [ "$IS_WAITING_LIST" == "true" ]; then
    echo -e "${GREEN}✓ TEST 2 PASADO: Agregado a lista de espera${NC}"
    echo "  - Waiting List ID: $WAITING_LIST_ID"
    echo "  - Posición en cola: $QUEUE_POSITION"
    echo "  - Total esperando en $SPECIALTY_RETURNED: $TOTAL_WAITING"
    echo "  - Especialidad solicitada: $SPECIALTY_RETURNED"
else
    echo -e "${YELLOW}⚠ TEST 2: La cita fue agendada normalmente (había cupos disponibles)${NC}"
    APPOINTMENT_ID=$(echo "$SCHEDULE_RESPONSE" | jq -r '.result.content[] | select(.text != null) | .text' | jq -r '.appointment_id' 2>/dev/null)
    echo "  - Appointment ID: $APPOINTMENT_ID"
fi

echo ""
sleep 2

# ============================================================================
# TEST 3: Consultar lista de espera para el paciente
# ============================================================================
echo -e "${YELLOW}TEST 3: Consultar lista de espera del paciente${NC}"

WAITING_LIST_RESPONSE=$(curl -s -X POST "$API_URL" \
  -H "Content-Type: application/json" \
  -d "{
    \"jsonrpc\": \"2.0\",
    \"id\": 4,
    \"method\": \"tools/call\",
    \"params\": {
      \"name\": \"getWaitingListAppointments\",
      \"arguments\": {
        \"patient_id\": $PATIENT_ID,
        \"status\": \"pending\"
      }
    }
  }")

echo "$WAITING_LIST_RESPONSE" | jq -r '.result.content[] | select(.text != null) | .text' | jq '.' 2>/dev/null

COUNT=$(echo "$WAITING_LIST_RESPONSE" | jq -r '.result.content[] | select(.text != null) | .text' | jq -r '.count' 2>/dev/null)

if [ ! -z "$COUNT" ] && [ "$COUNT" != "null" ]; then
    echo -e "${GREEN}✓ TEST 3 PASADO${NC}"
    echo "  - Solicitudes pendientes: $COUNT"
    
    if [ "$COUNT" -gt 0 ]; then
        FIRST_WAITING=$(echo "$WAITING_LIST_RESPONSE" | jq -r '.result.content[] | select(.text != null) | .text' | jq -r '.waiting_list[0]' 2>/dev/null)
        echo "  - Primera solicitud:"
        echo "$FIRST_WAITING" | jq '{
          waiting_list_id,
          queue_position,
          priority_level,
          specialty: .specialty.name,
          days_waiting,
          can_be_reassigned: .availability.can_be_reassigned
        }'
    fi
else
    echo -e "${RED}✗ TEST 3 FALLIDO${NC}"
fi

echo ""
sleep 2

# ============================================================================
# TEST 4: Verificar estructura de respuesta (enfoque en especialidad)
# ============================================================================
echo -e "${YELLOW}TEST 4: Verificar que la respuesta se enfoca en ESPECIALIDAD (no doctor específico)${NC}"

if [ "$IS_WAITING_LIST" == "true" ]; then
    HAS_SPECIALTY=$(echo "$SCHEDULE_RESPONSE" | jq -r '.result.content[] | select(.text != null) | .text' | jq -r '.requested_for.specialty' 2>/dev/null)
    HAS_LOCATION=$(echo "$SCHEDULE_RESPONSE" | jq -r '.result.content[] | select(.text != null) | .text' | jq -r '.requested_for.location' 2>/dev/null)
    NEXT_STEPS=$(echo "$SCHEDULE_RESPONSE" | jq -r '.result.content[] | select(.text != null) | .text' | jq -r '.next_steps' 2>/dev/null)
    
    if [ ! -z "$HAS_SPECIALTY" ] && [ "$HAS_SPECIALTY" != "null" ]; then
        echo -e "${GREEN}✓ TEST 4 PASADO: La respuesta se enfoca en especialidad${NC}"
        echo "  - Incluye especialidad: ✓"
        echo "  - Incluye ubicación: ✓"
        echo "  - Mensaje de próximos pasos: $NEXT_STEPS"
    else
        echo -e "${RED}✗ TEST 4 FALLIDO: No se encontró información de especialidad${NC}"
    fi
else
    echo -e "${YELLOW}⚠ TEST 4 OMITIDO: No hubo registro en lista de espera${NC}"
fi

echo ""

# ============================================================================
# RESUMEN
# ============================================================================
echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}RESUMEN DE PRUEBAS${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""
echo "Especialidad probada: $SPECIALTY_NAME"
echo "Patient ID utilizado: $PATIENT_ID"
echo ""
echo -e "${GREEN}✓ Sistema actualizado con enfoque en especialidad${NC}"
echo -e "${GREEN}✓ Lista de espera funcional${NC}"
echo -e "${GREEN}✓ Posición en cola calculada por especialidad (no por doctor)${NC}"
echo ""
echo -e "${YELLOW}Nota: Una operadora contactará al paciente cuando haya disponibilidad${NC}"
