const mysql = require('mysql2/promise');

// Configuración de conexión
const pool = mysql.createPool({
  host: '127.0.0.1',
  port: 3306,
  user: 'biosanar_user',
  password: '/6Tx0eXqFQONTFuoc7aqPicNlPhmuINU',
  database: 'biosanar',
  waitForConnections: true,
  connectionLimit: 10
});

async function testAddToWaitingListOptionalDate() {
  console.log('======================================');
  console.log('TEST addToWaitingList v1.4 - scheduled_date OPCIONAL');
  console.log('======================================\n');

  const connection = await pool.getConnection();
  
  try {
    // Test 1: Buscar un paciente activo
    console.log('✓ Test 1: Buscar paciente activo...');
    const [patients] = await connection.execute(
      'SELECT id, name, document FROM patients WHERE status = "Activo" LIMIT 1'
    );
    
    if (patients.length === 0) {
      console.log('❌ No se encontraron pacientes activos');
      return;
    }
    
    const patient = patients[0];
    console.log(`  Paciente: ${patient.name} (ID: ${patient.id})\n`);

    // Test 2: Buscar una disponibilidad activa
    console.log('✓ Test 2: Buscar disponibilidad activa...');
    const [availabilities] = await connection.execute(`
      SELECT a.id, s.name as specialty_name, s.id as specialty_id
      FROM availabilities a
      INNER JOIN specialties s ON a.specialty_id = s.id
      WHERE a.status = 'Activa' AND a.date >= CURDATE()
      LIMIT 1
    `);
    
    if (availabilities.length === 0) {
      console.log('❌ No se encontraron disponibilidades activas');
      return;
    }
    
    const availability = availabilities[0];
    console.log(`  Disponibilidad: ${availability.specialty_name} (ID: ${availability.id})\n`);

    // Limpiar registros anteriores del test
    console.log('✓ Test 3: Limpiar registros anteriores...');
    await connection.execute(`
      DELETE wl FROM appointments_waiting_list wl
      INNER JOIN availabilities a ON wl.availability_id = a.id
      WHERE wl.patient_id = ?
        AND a.specialty_id = ?
        AND wl.reason LIKE '%TEST%'
    `, [patient.id, availability.specialty_id]);
    console.log('  Registros de prueba limpiados\n');

    // Test 4: Insertar SIN scheduled_date (NULL)
    console.log('✓ Test 4: Insertar en lista de espera SIN fecha específica (scheduled_date = NULL)...');
    const [insertResult1] = await connection.execute(`
      INSERT INTO appointments_waiting_list (
        patient_id, availability_id, scheduled_date, appointment_type,
        reason, priority_level, status, requested_by, call_type, created_at
      ) VALUES (?, ?, NULL, 'Presencial', ?, 'Normal', 'pending', 'Test_Script', 'normal', NOW())
    `, [patient.id, availability.id, 'Control médico - TEST SIN FECHA']);
    
    const waiting_id_1 = insertResult1.insertId;
    console.log(`  ✅ Insertado con ID: ${waiting_id_1}`);
    console.log(`  ✅ scheduled_date = NULL (se asignará cuando haya cupo)\n`);

    // Verificar
    const [check1] = await connection.execute(
      'SELECT id, scheduled_date, reason FROM appointments_waiting_list WHERE id = ?',
      [waiting_id_1]
    );
    console.log('  Verificación:', check1[0]);
    console.log('  ✅ scheduled_date es NULL:', check1[0].scheduled_date === null ? 'Sí' : 'No\n');

    // Test 5: Insertar CON scheduled_date
    console.log('\n✓ Test 5: Insertar en lista de espera CON fecha específica...');
    
    // Primero eliminar el registro anterior para evitar duplicado por especialidad
    await connection.execute('DELETE FROM appointments_waiting_list WHERE id = ?', [waiting_id_1]);
    
    const [insertResult2] = await connection.execute(`
      INSERT INTO appointments_waiting_list (
        patient_id, availability_id, scheduled_date, appointment_type,
        reason, priority_level, status, requested_by, call_type, created_at
      ) VALUES (?, ?, '2025-10-25 14:00:00', 'Telemedicina', ?, 'Alta', 'pending', 'Test_Script', 'normal', NOW())
    `, [patient.id, availability.id, 'Control médico - TEST CON FECHA']);
    
    const waiting_id_2 = insertResult2.insertId;
    console.log(`  ✅ Insertado con ID: ${waiting_id_2}`);
    console.log(`  ✅ scheduled_date = 2025-10-25 14:00:00 (fecha solicitada por paciente)\n`);

    // Verificar
    const [check2] = await connection.execute(
      'SELECT id, scheduled_date, reason, priority_level FROM appointments_waiting_list WHERE id = ?',
      [waiting_id_2]
    );
    console.log('  Verificación:', check2[0]);
    console.log('  ✅ scheduled_date tiene valor:', check2[0].scheduled_date !== null ? 'Sí\n' : 'No\n');

    // Test 6: Verificar que ambos modos funcionan en consultas
    console.log('✓ Test 6: Consultar lista de espera (ambos registros)...');
    const [waitingList] = await connection.execute(`
      SELECT 
        wl.id, wl.scheduled_date, wl.reason, wl.priority_level, wl.appointment_type,
        p.name as patient_name, s.name as specialty_name
      FROM appointments_waiting_list wl
      INNER JOIN patients p ON wl.patient_id = p.id
      INNER JOIN availabilities a ON wl.availability_id = a.id
      INNER JOIN specialties s ON a.specialty_id = s.id
      WHERE wl.patient_id = ? AND wl.status = 'pending'
      ORDER BY wl.id DESC
      LIMIT 2
    `, [patient.id]);

    console.log(`  Se encontraron ${waitingList.length} registros en lista de espera:\n`);
    waitingList.forEach((item, index) => {
      console.log(`  ${index + 1}. ID: ${item.id}`);
      console.log(`     Paciente: ${item.patient_name}`);
      console.log(`     Especialidad: ${item.specialty_name}`);
      console.log(`     Fecha deseada: ${item.scheduled_date || 'Sin fecha específica - Por asignar'}`);
      console.log(`     Prioridad: ${item.priority_level}`);
      console.log(`     Tipo: ${item.appointment_type}`);
      console.log('');
    });

    // Limpiar registros de prueba
    console.log('✓ Test 7: Limpieza de registros de prueba...');
    await connection.execute(
      'DELETE FROM appointments_waiting_list WHERE id IN (?, ?)',
      [waiting_id_1, waiting_id_2]
    );
    console.log('  ✅ Registros eliminados\n');

    console.log('======================================');
    console.log('✅ TODOS LOS TESTS PASARON');
    console.log('======================================');
    console.log('\n📋 RESUMEN:');
    console.log('  ✓ scheduled_date puede ser NULL (opcional)');
    console.log('  ✓ scheduled_date puede tener una fecha específica');
    console.log('  ✓ Ambos casos se insertan correctamente');
    console.log('  ✓ Ambos casos se consultan correctamente');
    console.log('\n🎯 La herramienta addToWaitingList está lista:');
    console.log('  - Si el paciente NO tiene fecha preferida: scheduled_date = NULL');
    console.log('  - Si el paciente SÍ tiene fecha preferida: scheduled_date = "YYYY-MM-DD HH:MM:SS"');
    console.log('  - La operadora asignará fecha cuando haya disponibilidad\n');

  } catch (error) {
    console.error('❌ ERROR:', error.message);
    console.error(error.stack);
  } finally {
    connection.release();
    await pool.end();
  }
}

testAddToWaitingListOptionalDate();
