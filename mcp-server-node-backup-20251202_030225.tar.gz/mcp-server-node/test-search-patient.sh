#!/bin/bash

# Test completo de la herramienta searchPatient
# Busca pacientes ACTIVOS en la base de datos

echo "=========================================="
echo "TEST 1: Buscar sin criterios (DEBE FALLAR)"
echo "=========================================="
curl -s -X POST http://localhost:8977/mcp-unified \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 1,
    "method": "tools/call",
    "params": {
      "name": "searchPatient",
      "arguments": {}
    }
  }' | jq .

echo -e "\n\n=========================================="
echo "TEST 2: Buscar por documento (existente)"
echo "=========================================="
curl -s -X POST http://localhost:8977/mcp-unified \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 2,
    "method": "tools/call",
    "params": {
      "name": "searchPatient",
      "arguments": {
        "document": "17265900"
      }
    }
  }' | jq .

echo -e "\n\n=========================================="
echo "TEST 3: Buscar por nombre parcial"
echo "=========================================="
curl -s -X POST http://localhost:8977/mcp-unified \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 3,
    "method": "tools/call",
    "params": {
      "name": "searchPatient",
      "arguments": {
        "name": "Dave"
      }
    }
  }' | jq .

echo -e "\n\n=========================================="
echo "TEST 4: Buscar por teléfono"
echo "=========================================="
curl -s -X POST http://localhost:8977/mcp-unified \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 4,
    "method": "tools/call",
    "params": {
      "name": "searchPatient",
      "arguments": {
        "phone": "04263774021"
      }
    }
  }' | jq .

echo -e "\n\n=========================================="
echo "TEST 5: Buscar por ID de paciente"
echo "=========================================="
curl -s -X POST http://localhost:8977/mcp-unified \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 5,
    "method": "tools/call",
    "params": {
      "name": "searchPatient",
      "arguments": {
        "patient_id": 1057
      }
    }
  }' | jq .

echo -e "\n\n=========================================="
echo "TEST 6: Buscar paciente inexistente"
echo "=========================================="
curl -s -X POST http://localhost:8977/mcp-unified \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 6,
    "method": "tools/call",
    "params": {
      "name": "searchPatient",
      "arguments": {
        "document": "999999999999"
      }
    }
  }' | jq .

echo -e "\n\n=========================================="
echo "TEST 7: Buscar por múltiples criterios"
echo "=========================================="
curl -s -X POST http://localhost:8977/mcp-unified \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 7,
    "method": "tools/call",
    "params": {
      "name": "searchPatient",
      "arguments": {
        "name": "Bastidas",
        "document": "17265900"
      }
    }
  }' | jq .

echo -e "\n\n=========================================="
echo "TEST 8: Buscar pacientes recientes por nombre"
echo "=========================================="
curl -s -X POST http://localhost:8977/mcp-unified \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 8,
    "method": "tools/call",
    "params": {
      "name": "searchPatient",
      "arguments": {
        "name": "María"
      }
    }
  }' | jq .

echo -e "\n\n=========================================="
echo "TEST 9: Verificar Schema de searchPatient"
echo "=========================================="
curl -s -X POST http://localhost:8977/mcp-unified \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 9,
    "method": "tools/list"
  }' | jq '.result.tools[] | select(.name == "searchPatient")'

echo -e "\n\n✅ Tests completados!"
