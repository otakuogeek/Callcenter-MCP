#!/bin/bash

echo "======================================================================"
echo "TEST FINAL: addToWaitingList SOLO con patient_id, specialty_id, reason"
echo "======================================================================"
echo ""

# Test 1: Solo campos obligatorios (SIN availability_id)
echo "📝 TEST 1: Agregar a lista de espera SIN availability_id"
echo "Parámetros: patient_id=1057, specialty_id=3 (Cardiología), reason='Consulta urgente'"
echo ""

curl -s -X POST http://localhost:8977/mcp-unified \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 1,
    "method": "tools/call",
    "params": {
      "name": "addToWaitingList",
      "arguments": {
        "patient_id": 1057,
        "specialty_id": 3,
        "reason": "Consulta de cardiología urgente"
      }
    }
  }' | python3 -m json.tool

echo ""
echo "======================================================================"
echo ""

# Test 2: Con specialty_id diferente
echo "📝 TEST 2: Agregar a lista de espera para Dermatología (ID: 10)"
echo "Parámetros: patient_id=1058, specialty_id=10, reason='Consulta dermatológica'"
echo ""

curl -s -X POST http://localhost:8977/mcp-unified \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 2,
    "method": "tools/call",
    "params": {
      "name": "addToWaitingList",
      "arguments": {
        "patient_id": 1058,
        "specialty_id": 10,
        "reason": "Consulta dermatológica"
      }
    }
  }' | python3 -m json.tool

echo ""
echo "======================================================================"
echo "✅ TESTS COMPLETADOS"
echo "======================================================================"
