const http = require('http');

const DB_USER = 'biosanar_user';
const DB_PASS = '/6Tx0eXqFQONTFuoc7aqPicNlPhmuINU';
const auth = Buffer.from(`${DB_USER}:${DB_PASS}`).toString('base64');

console.log('========================================');
console.log('TEST: addToWaitingList SIN scheduled_date');
console.log('========================================\n');

// Test 1: Sin fecha programada
const test1 = {
  jsonrpc: '2.0',
  id: 1,
  method: 'tools/call',
  params: {
    name: 'addToWaitingList',
    arguments: {
      patient_id: 1057, // Dave Bastidas - Activo
      availability_id: 155, // Availability real
      appointment_type: 'Presencial',
      reason: 'Consulta de control general - fecha flexible',
      notes: 'Paciente puede asistir cualquier día disponible',
      priority_level: 'Normal',
      requested_by: 'Test_Sistema',
      call_type: 'normal'
      // NO incluimos scheduled_date
    }
  }
};

const options = {
  hostname: 'localhost',
  port: 8977,
  path: '/mcp-unified',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': `Basic ${auth}`
  }
};

console.log('📋 Test 1: Agregar paciente SIN fecha programada');
console.log('---\n');

const req1 = http.request(options, (res) => {
  let data = '';
  
  res.on('data', (chunk) => {
    data += chunk;
  });
  
  res.on('end', () => {
    try {
      const result = JSON.parse(data);
      console.log('Resultado Test 1:');
      console.log(JSON.stringify(result, null, 2));
      
      if (result.result && result.result.success) {
        console.log('\n✅ Test 1 PASSED: Paciente agregado sin fecha programada');
        console.log(`   - ID Lista Espera: ${result.result.waiting_list_id}`);
        console.log(`   - Posición en cola: ${result.result.queue_position || 'N/A'}`);
      } else {
        console.log('\n❌ Test 1 FAILED');
      }
      
      // Ejecutar Test 2
      runTest2();
      
    } catch (e) {
      console.error('Error parsing response:', e);
      console.log('Raw response:', data);
    }
  });
});

req1.on('error', (e) => {
  console.error(`Error en Test 1: ${e.message}`);
});

req1.write(JSON.stringify(test1));
req1.end();

function runTest2() {
  console.log('\n========================================');
  console.log('Test 2: Con fecha programada (opcional)');
  console.log('========================================\n');
  
  const test2 = {
    jsonrpc: '2.0',
    id: 2,
    method: 'tools/call',
    params: {
      name: 'addToWaitingList',
      arguments: {
        patient_id: 1058, // Janet Rocío Bernal Chávez - Activo
        availability_id: 156, // Availability real
        scheduled_date: '2025-10-22 10:00:00', // Esta vez SÍ incluimos la fecha
        appointment_type: 'Telemedicina',
        reason: 'Consulta especializada - fecha preferida',
        notes: 'Paciente prefiere esta fecha pero acepta otras',
        priority_level: 'Alta',
        requested_by: 'Test_Sistema',
        call_type: 'normal'
      }
    }
  };
  
  const req2 = http.request(options, (res) => {
    let data = '';
    
    res.on('data', (chunk) => {
      data += chunk;
    });
    
    res.on('end', () => {
      try {
        const result = JSON.parse(data);
        console.log('Resultado Test 2:');
        console.log(JSON.stringify(result, null, 2));
        
        if (result.result && result.result.success) {
          console.log('\n✅ Test 2 PASSED: Paciente agregado con fecha programada');
          console.log(`   - ID Lista Espera: ${result.result.waiting_list_id}`);
          console.log(`   - Posición en cola: ${result.result.queue_position || 'N/A'}`);
        } else {
          console.log('\n❌ Test 2 FAILED');
        }
        
        console.log('\n✅ Tests completados');
        
      } catch (e) {
        console.error('Error parsing response:', e);
        console.log('Raw response:', data);
      }
    });
  });
  
  req2.on('error', (e) => {
    console.error(`Error en Test 2: ${e.message}`);
  });
  
  req2.write(JSON.stringify(test2));
  req2.end();
}
