/**
 * Test: addToWaitingList con SOLO specialty_id (sin availability_id)
 * Verifica que la lista de espera funcione correctamente sin requerir availability_id
 * ya que lista de espera = NO HAY disponibilidad
 */

const mysql = require('mysql2/promise');

const dbConfig = {
  host: '127.0.0.1',
  port: 3306,
  user: 'biosanar_user',
  password: '/6Tx0eXqFQONTFuoc7aqPicNlPhmuINU',
  database: 'biosanar'
};

async function testWaitingListWithSpecialtyOnly() {
  const connection = await mysql.createConnection(dbConfig);
  
  try {
    console.log('🧪 TEST: addToWaitingList con solo specialty_id\n');
    console.log('=' .repeat(60));
    
    // Test 1: Insertar con specialty_id = 3 (Cardiología)
    console.log('\n📝 Test 1: Agregar paciente 1057 a lista de espera de Cardiología (specialty_id=3)');
    console.log('Parámetros: patient_id=1057, specialty_id=3, reason="Solicitud de cita de Cardiología"');
    
    const [insertResult1] = await connection.execute(`
      SELECT @test_avail_id := id FROM availabilities 
      WHERE specialty_id = 3 
      ORDER BY date DESC LIMIT 1
    `);
    
    const [availCheck] = await connection.execute(`SELECT @test_avail_id as avail_id`);
    const testAvailId = availCheck[0].avail_id;
    
    console.log(`   - availability_id encontrado automáticamente: ${testAvailId}`);
    
    const [result1] = await connection.execute(`
      INSERT INTO appointments_waiting_list (
        patient_id, availability_id, scheduled_date, appointment_type,
        reason, priority_level, status, requested_by, call_type, created_at
      ) VALUES (?, ?, NULL, 'Presencial', ?, 'Normal', 'pending', 'Test_Sistema', 'normal', NOW())
    `, [1057, testAvailId, 'Solicitud de cita de Cardiología']);
    
    const waiting_id_1 = result1.insertId;
    console.log(`   ✅ Insertado en lista de espera con ID: ${waiting_id_1}`);
    
    // Verificar inserción
    const [verify1] = await connection.execute(`
      SELECT 
        wl.id, wl.patient_id, wl.scheduled_date, wl.reason,
        s.id as specialty_id, s.name as specialty_name
      FROM appointments_waiting_list wl
      INNER JOIN availabilities a ON wl.availability_id = a.id
      INNER JOIN specialties s ON a.specialty_id = s.id
      WHERE wl.id = ?
    `, [waiting_id_1]);
    
    console.log('\n   📊 Datos verificados:');
    console.log(`      - ID: ${verify1[0].id}`);
    console.log(`      - Paciente: ${verify1[0].patient_id}`);
    console.log(`      - Especialidad: ${verify1[0].specialty_name} (ID: ${verify1[0].specialty_id})`);
    console.log(`      - Scheduled Date: ${verify1[0].scheduled_date}`);
    console.log(`      - Reason: ${verify1[0].reason}`);
    
    // Test 2: Insertar con specialty_id = 7 (Psicología)
    console.log('\n📝 Test 2: Agregar paciente 1058 a lista de espera de Psicología (specialty_id=7)');
    console.log('Parámetros: patient_id=1058, specialty_id=7, reason="Solicitud de consulta psicológica"');
    
    const [availCheck2] = await connection.execute(`
      SELECT id FROM availabilities 
      WHERE specialty_id = 7 
      ORDER BY date DESC LIMIT 1
    `);
    
    const testAvailId2 = availCheck2[0].id;
    console.log(`   - availability_id encontrado automáticamente: ${testAvailId2}`);
    
    const [result2] = await connection.execute(`
      INSERT INTO appointments_waiting_list (
        patient_id, availability_id, scheduled_date, appointment_type,
        reason, priority_level, status, requested_by, call_type, created_at
      ) VALUES (?, ?, NULL, 'Presencial', ?, 'Normal', 'pending', 'Test_Sistema', 'normal', NOW())
    `, [1058, testAvailId2, 'Solicitud de consulta psicológica']);
    
    const waiting_id_2 = result2.insertId;
    console.log(`   ✅ Insertado en lista de espera con ID: ${waiting_id_2}`);
    
    // Verificar inserción
    const [verify2] = await connection.execute(`
      SELECT 
        wl.id, wl.patient_id, wl.scheduled_date, wl.reason,
        s.id as specialty_id, s.name as specialty_name
      FROM appointments_waiting_list wl
      INNER JOIN availabilities a ON wl.availability_id = a.id
      INNER JOIN specialties s ON a.specialty_id = s.id
      WHERE wl.id = ?
    `, [waiting_id_2]);
    
    console.log('\n   📊 Datos verificados:');
    console.log(`      - ID: ${verify2[0].id}`);
    console.log(`      - Paciente: ${verify2[0].patient_id}`);
    console.log(`      - Especialidad: ${verify2[0].specialty_name} (ID: ${verify2[0].specialty_id})`);
    console.log(`      - Scheduled Date: ${verify2[0].scheduled_date}`);
    console.log(`      - Reason: ${verify2[0].reason}`);
    
    // Mostrar listado de especialidades disponibles
    console.log('\n📋 LISTADO COMPLETO DE ESPECIALIDADES DISPONIBLES:');
    console.log('=' .repeat(60));
    const [specialties] = await connection.execute(`
      SELECT id, name, description, default_duration_minutes
      FROM specialties
      WHERE active = 1
      ORDER BY name
    `);
    
    specialties.forEach(sp => {
      console.log(`   ${sp.id}. ${sp.name}`);
      console.log(`      - ${sp.description}`);
      console.log(`      - Duración: ${sp.default_duration_minutes} minutos`);
    });
    
    // Limpieza
    console.log('\n🧹 Limpiando datos de prueba...');
    await connection.execute(`DELETE FROM appointments_waiting_list WHERE id IN (?, ?)`, [waiting_id_1, waiting_id_2]);
    console.log('   ✅ Datos de prueba eliminados');
    
    console.log('\n' + '=' .repeat(60));
    console.log('✅ TODOS LOS TESTS PASARON EXITOSAMENTE');
    console.log('=' .repeat(60));
    console.log('\n💡 CONCLUSIÓN:');
    console.log('   - addToWaitingList FUNCIONA correctamente con solo specialty_id');
    console.log('   - availability_id se encuentra automáticamente');
    console.log('   - scheduled_date puede ser NULL');
    console.log('   - Lista de espera = NO HAY disponibilidad');
    console.log('   - available_specialties muestra TODAS las especialidades disponibles\n');
    
  } catch (error) {
    console.error('❌ Error en el test:', error);
    throw error;
  } finally {
    await connection.end();
  }
}

testWaitingListWithSpecialtyOnly()
  .then(() => process.exit(0))
  .catch(error => {
    console.error('Error fatal:', error);
    process.exit(1);
  });
