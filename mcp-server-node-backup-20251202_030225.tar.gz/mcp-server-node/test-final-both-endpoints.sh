#!/bin/bash

echo "🎯 TEST FINAL: Ambos Endpoints MCP con 2 Herramientas"
echo "======================================================"

echo ""
echo "📊 CONFIGURACIÓN ACTUAL"
echo "----------------------"
echo "✅ Endpoint Principal: https://biosanarcall.site/mcp/"
echo "   - Servidor: mcp-unified (Puerto 8977)"
echo "   - Herramientas: 2"
echo ""
echo "✅ Endpoint ElevenLabs: https://biosanarcall.site/mcp-elevenlabs/"
echo "   - Servidor: mcp-simple-register (Puerto 8978)"
echo "   - Herramientas: 2"
echo ""

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "1️⃣  TEST: Endpoint Principal (/mcp/)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

echo ""
echo "📋 Listar Herramientas:"
curl -s -X POST https://biosanarcall.site/mcp/ \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}' | \
  jq -r '.result.tools[] | "  ✅ " + .name'

echo ""
echo "🏥 Test listActiveEPS:"
curl -s -X POST https://biosanarcall.site/mcp/ \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","id":2,"method":"tools/call","params":{"name":"listActiveEPS","arguments":{}}}' | \
  jq -r '.result.content[0].text | fromjson | 
    "  📊 EPS Activas: " + (.count | tostring) + "\n  🏥 Ejemplo: " + .eps_list[0].name + " (ID: " + (.eps_list[0].id | tostring) + ")"'

echo ""
echo "👤 Test registerPatientSimple:"
RANDOM_NUM=$((20000 + RANDOM % 80000))
curl -s -X POST https://biosanarcall.site/mcp/ \
  -H "Content-Type: application/json" \
  -d "{
    \"jsonrpc\":\"2.0\",
    \"id\":3,
    \"method\":\"tools/call\",
    \"params\":{
      \"name\":\"registerPatientSimple\",
      \"arguments\":{
        \"document\":\"MCP$RANDOM_NUM\",
        \"name\":\"Test Endpoint Principal\",
        \"phone\":\"310$RANDOM_NUM\",
        \"insurance_eps_id\":14,
        \"notes\":\"Test desde /mcp/\"
      }
    }
  }" | \
  jq -r '.result.content[0].text | fromjson | 
    if .success then 
      "  ✅ Registrado: " + .patient.name + " (ID: " + (.patient_id | tostring) + ")\n  🏥 EPS: " + .patient.eps
    else 
      "  ❌ Error: " + .error
    end'

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "2️⃣  TEST: Endpoint ElevenLabs (/mcp-elevenlabs/)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

echo ""
echo "📋 Listar Herramientas:"
curl -s -X POST https://biosanarcall.site/mcp-elevenlabs/ \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}' | \
  jq -r '.result.tools[] | "  ✅ " + .name'

echo ""
echo "🏥 Test listActiveEPS:"
curl -s -X POST https://biosanarcall.site/mcp-elevenlabs/ \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","id":2,"method":"tools/call","params":{"name":"listActiveEPS","arguments":{}}}' | \
  jq -r '.result.content[0].text | fromjson | 
    "  📊 EPS Activas: " + (.count | tostring) + "\n  🏥 Primera: " + .eps_list[0].name + " (ID: " + (.eps_list[0].id | tostring) + ")"'

echo ""
echo "👤 Test registerPatientSimple:"
RANDOM_NUM2=$((30000 + RANDOM % 70000))
curl -s -X POST https://biosanarcall.site/mcp-elevenlabs/ \
  -H "Content-Type: application/json" \
  -d "{
    \"jsonrpc\":\"2.0\",
    \"id\":3,
    \"method\":\"tools/call\",
    \"params\":{
      \"name\":\"registerPatientSimple\",
      \"arguments\":{
        \"document\":\"ELEV$RANDOM_NUM2\",
        \"name\":\"Test Endpoint ElevenLabs\",
        \"phone\":\"320$RANDOM_NUM2\",
        \"insurance_eps_id\":9,
        \"notes\":\"Test desde /mcp-elevenlabs/\"
      }
    }
  }" | \
  jq -r '.result.content[0].text | fromjson | 
    if .success then 
      "  ✅ Registrado: " + .patient.name + " (ID: " + (.patient_id | tostring) + ")\n  🏥 EPS: " + .patient.eps
    else 
      "  ❌ Error: " + .error
    end'

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📊 RESUMEN FINAL"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

echo ""
echo "✅ AMBOS ENDPOINTS FUNCIONANDO CON 2 HERRAMIENTAS"
echo ""
echo "🛠️  Herramientas Disponibles:"
echo "   1. listActiveEPS - Consulta EPS activas"
echo "   2. registerPatientSimple - Registro de pacientes"
echo ""
echo "🎯 Flujo de Trabajo:"
echo "   Paso 1: Llamar listActiveEPS para ver EPS disponibles"
echo "   Paso 2: Usar ID de EPS en registerPatientSimple"
echo "   Paso 3: Verificar respuesta con paciente creado"
echo ""
echo "📋 EPS Activas en Sistema:"
mysql -u biosanar_user -pBiosanar2024! biosanar -e "
  SELECT COUNT(*) as total FROM eps WHERE status = 'active'
" 2>/dev/null | tail -1 | awk '{print "   Total: " $1 " EPS activas"}'

echo ""
echo "👥 Pacientes Registrados Hoy:"
mysql -u biosanar_user -pBiosanar2024! biosanar -e "
  SELECT COUNT(*) as total FROM patients 
  WHERE DATE(created_at) = CURDATE()
" 2>/dev/null | tail -1 | awk '{print "   Total: " $1 " pacientes"}'

echo ""
echo "🎉 SISTEMA COMPLETAMENTE FUNCIONAL"
echo ""
