#!/bin/bash

# ====================================================================
# Script de Prueba - Sistema de Gestión de Embarazos MCP
# ====================================================================

BASE_URL="http://localhost:8977/mcp-unified"

echo "======================================================================"
echo "🤰 PRUEBAS DEL SISTEMA DE GESTIÓN DE EMBARAZOS - MCP BIOSANARCALL"
echo "======================================================================"
echo ""

# ====================================================================
# TEST 1: Listar herramientas disponibles (verificar nuevas herramientas)
# ====================================================================
echo "📋 TEST 1: Verificar herramientas de gestión de embarazos"
echo "----------------------------------------------------------------------"
curl -s -X POST "$BASE_URL" \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 1,
    "method": "tools/list"
  }' | jq '.result.tools[] | select(.name | contains("Pregn") or contains("Prenatal")) | {name: .name, description: .description}'

echo ""
echo ""

# ====================================================================
# TEST 2: Buscar o crear paciente femenina para pruebas
# ====================================================================
echo "👤 TEST 2: Buscar paciente femenina de prueba"
echo "----------------------------------------------------------------------"
# Nota: En producción, primero deberías buscar si existe el paciente
# Para este ejemplo, asumimos patient_id = 1037 (ajusta según tu BD)

PATIENT_ID=1037
echo "📝 Usando patient_id: $PATIENT_ID"
echo ""
echo ""

# ====================================================================
# TEST 3: Registrar embarazo
# ====================================================================
echo "🤰 TEST 3: Registrar nuevo embarazo"
echo "----------------------------------------------------------------------"
echo "📅 FUM: 01/02/2025 (1 de febrero de 2025)"
echo ""

PREGNANCY_RESPONSE=$(curl -s -X POST "$BASE_URL" \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 3,
    "method": "tools/call",
    "params": {
      "name": "registerPregnancy",
      "arguments": {
        "patient_id": '"$PATIENT_ID"',
        "last_menstrual_date": "01/02/2025",
        "high_risk": false,
        "notes": "Embarazo de prueba registrado desde script de testing"
      }
    }
  }')

echo "$PREGNANCY_RESPONSE" | jq '.'

# Extraer pregnancy_id si fue exitoso
PREGNANCY_ID=$(echo "$PREGNANCY_RESPONSE" | jq -r '.result.content[0].text' | jq -r '.pregnancy_id // empty')

if [ -n "$PREGNANCY_ID" ]; then
  echo ""
  echo "✅ Embarazo registrado con ID: $PREGNANCY_ID"
else
  echo ""
  echo "⚠️  No se pudo obtener pregnancy_id (puede ser que ya exista un embarazo activo)"
  # En caso de que ya exista, usar un ID conocido
  PREGNANCY_ID=1
fi

echo ""
echo ""

# ====================================================================
# TEST 4: Consultar embarazos activos
# ====================================================================
echo "📊 TEST 4: Consultar embarazos activos"
echo "----------------------------------------------------------------------"

curl -s -X POST "$BASE_URL" \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 4,
    "method": "tools/call",
    "params": {
      "name": "getActivePregnancies",
      "arguments": {
        "limit": 10
      }
    }
  }' | jq '.'

echo ""
echo ""

# ====================================================================
# TEST 5: Consultar embarazos de paciente específica
# ====================================================================
echo "👤 TEST 5: Consultar embarazos de paciente específica"
echo "----------------------------------------------------------------------"

curl -s -X POST "$BASE_URL" \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 5,
    "method": "tools/call",
    "params": {
      "name": "getActivePregnancies",
      "arguments": {
        "patient_id": '"$PATIENT_ID"'
      }
    }
  }' | jq '.'

echo ""
echo ""

# ====================================================================
# TEST 6: Registrar control prenatal (solo si tenemos pregnancy_id válido)
# ====================================================================
if [ -n "$PREGNANCY_ID" ] && [ "$PREGNANCY_ID" != "null" ]; then
  echo "📋 TEST 6: Registrar control prenatal"
  echo "----------------------------------------------------------------------"
  
  curl -s -X POST "$BASE_URL" \
    -H "Content-Type: application/json" \
    -d '{
      "jsonrpc": "2.0",
      "id": 6,
      "method": "tools/call",
      "params": {
        "name": "registerPrenatalControl",
        "arguments": {
          "pregnancy_id": '"$PREGNANCY_ID"',
          "control_date": "2025-10-13",
          "gestational_weeks": 36,
          "gestational_days": 2,
          "weight_kg": 72.5,
          "blood_pressure_systolic": 120,
          "blood_pressure_diastolic": 80,
          "fundal_height_cm": 34.0,
          "fetal_heart_rate": 140,
          "observations": "Embarazo evolucionando favorablemente",
          "recommendations": "Continuar con controles semanales",
          "next_control_date": "2025-10-20",
          "ultrasound_performed": false
        }
      }
    }' | jq '.'
  
  echo ""
  echo ""
fi

# ====================================================================
# TEST 7: Consultar solo embarazos de alto riesgo
# ====================================================================
echo "⚠️  TEST 7: Consultar solo embarazos de alto riesgo"
echo "----------------------------------------------------------------------"

curl -s -X POST "$BASE_URL" \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 7,
    "method": "tools/call",
    "params": {
      "name": "getActivePregnancies",
      "arguments": {
        "high_risk_only": true,
        "limit": 10
      }
    }
  }' | jq '.'

echo ""
echo ""

# ====================================================================
# RESUMEN
# ====================================================================
echo "======================================================================"
echo "✅ PRUEBAS COMPLETADAS"
echo "======================================================================"
echo ""
echo "Herramientas nuevas agregadas:"
echo "  1. registerPregnancy - Registrar embarazo (solo requiere FUM)"
echo "  2. getActivePregnancies - Consultar embarazos activos"
echo "  3. updatePregnancyStatus - Actualizar estado (Completada/Interrumpida)"
echo "  4. registerPrenatalControl - Registrar controles prenatales"
echo ""
echo "Total de herramientas MCP: 12 (8 originales + 4 nuevas)"
echo ""
echo "📚 Para más información, consulte:"
echo "   - DOCUMENTACION_GESTION_EMBARAZOS.md"
echo "   - newprompt-pregnancy.md (prompt actualizado con gestión de embarazos)"
echo ""
echo "======================================================================"
