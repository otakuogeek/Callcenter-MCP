#!/bin/bash

echo "🎯 Test ESPECÍFICO del Endpoint ElevenLabs"
echo "=========================================="

ELEVENLABS_URL="https://biosanarcall.site/mcp-elevenlabs/"

echo ""
echo "1. 📊 Información del Servidor (GET)..."
curl -s "$ELEVENLABS_URL" | jq -r '
  "🏥 Servidor: " + .server + 
  "\n📦 Versión: " + .version + 
  "\n🛠️ Herramientas: " + (.tools_count | tostring) + 
  "\n🔌 Protocolo: " + .protocol + 
  "\n⏰ Estado: " + .status'

echo ""
echo "2. 🛠️ Listado de Herramientas (POST)..."
TOOLS_RESPONSE=$(curl -s -X POST "$ELEVENLABS_URL" \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc": "2.0", "id": 1, "method": "tools/list"}')

TOOLS_COUNT=$(echo "$TOOLS_RESPONSE" | jq '.result.tools | length')
echo "📊 Cantidad de herramientas: $TOOLS_COUNT"

if [ "$TOOLS_COUNT" = "1" ]; then
    echo "✅ CORRECTO: Solo 1 herramienta disponible"
    echo "$TOOLS_RESPONSE" | jq -r '.result.tools[0] | "📋 Herramienta: " + .name + "\n📝 Descripción: " + .description'
else
    echo "❌ ERROR: Se esperaba 1 herramienta, se encontraron $TOOLS_COUNT"
fi

echo ""
echo "3. ✅ Test de Registro de Paciente..."
REGISTER_RESPONSE=$(curl -s -X POST "$ELEVENLABS_URL" \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 2,
    "method": "tools/call",
    "params": {
      "name": "registerPatientSimple",
      "arguments": {
        "document": "ELEV001",
        "name": "Test ElevenLabs Endpoint",
        "phone": "3100001111",
        "insurance_eps_id": 14,
        "notes": "Prueba desde endpoint específico de ElevenLabs"
      }
    }
  }')

echo "$REGISTER_RESPONSE" | jq -r '.result.content[0].text | fromjson | 
  if .success then 
    "✅ REGISTRO EXITOSO\n👤 Paciente: " + .patient.name + "\n🆔 ID: " + (.patient_id | tostring) + "\n🏥 EPS: " + .patient.eps
  else 
    "❌ ERROR EN REGISTRO: " + .error
  end'

echo ""
echo "4. 🔍 Headers HTTP del Endpoint..."
curl -s -I "$ELEVENLABS_URL" | grep -E "(access-control|x-mcp|x-elevenlabs|content-type)"

echo ""
echo "5. 🌐 Test CORS Preflight..."
CORS_STATUS=$(curl -s -X OPTIONS "$ELEVENLABS_URL" \
  -H "Origin: https://elevenlabs.io" \
  -H "Access-Control-Request-Method: POST" \
  -H "Access-Control-Request-Headers: Content-Type" \
  -w "%{http_code}" -o /dev/null)

if [ "$CORS_STATUS" = "200" ] || [ "$CORS_STATUS" = "204" ]; then
  echo "✅ CORS Preflight: OK (Status: $CORS_STATUS)"
else
  echo "❌ CORS Preflight: FALLO (Status: $CORS_STATUS)"
fi

echo ""
echo "🎯 RESUMEN PARA ELEVENLABS:"
echo "=========================="
echo "✅ URL Confirmada: $ELEVENLABS_URL"
echo "✅ Herramientas: 1 (registerPatientSimple)"
echo "✅ Protocolo: JSON-RPC 2.0"
echo "✅ CORS: Configurado"
echo "✅ Registro: Funcional"
echo ""
echo "📋 Para configurar en ElevenLabs Agent Studio:"
echo "   URL del servidor: $ELEVENLABS_URL"
echo "   Herramienta principal: registerPatientSimple"
echo ""