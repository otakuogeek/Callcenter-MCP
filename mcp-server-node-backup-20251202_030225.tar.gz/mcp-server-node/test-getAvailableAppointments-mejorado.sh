#!/bin/bash

# Script de prueba para getAvailableAppointments mejorado
# Verifica que las citas se agrupan correctamente por médico y especialidad

API_URL="https://biosanarcall.site/mcp-unified"
TOKEN="Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwibmFtZSI6IkFkbWluIiwicm9sZSI6ImFkbWluIiwiaWF0IjoxNzI3MjU5NjAwfQ.J8xqKZm4nE3n6rH-7-yN8uYvK7TpQjL6vX0aB4cD7Ek"

echo "=========================================="
echo "PRUEBA 1: Obtener TODAS las disponibilidades"
echo "Verificar que se agrupan correctamente por médico"
echo "=========================================="

curl -X POST "$API_URL" \
  -H "Content-Type: application/json" \
  -H "Authorization: $TOKEN" \
  -d '{
    "jsonrpc": "2.0",
    "id": 1,
    "method": "tools/call",
    "params": {
      "name": "getAvailableAppointments",
      "arguments": {
        "limit": 100
      }
    }
  }' | jq '.result.content[0].text | fromjson | {
    message,
    count,
    doctors_with_availability,
    grouped_by_doctor_and_specialty: .grouped_by_doctor_and_specialty | map({
      date,
      doctor_name: .doctor.name,
      specialty_name: .specialty.name,
      availabilities_count: (.availabilities | length),
      total_slots: .total_slots_available,
      has_morning: .has_morning_slots,
      has_afternoon: .has_afternoon_slots,
      has_multiple_shifts: .has_multiple_shifts,
      time_slots: [.availabilities[].time_range]
    })
  }'

echo ""
echo ""
echo "=========================================="
echo "PRUEBA 2: Filtrar por especialidad específica"
echo "Verificar que solo muestra médicos de esa especialidad"
echo "=========================================="

curl -X POST "$API_URL" \
  -H "Content-Type: application/json" \
  -H "Authorization: $TOKEN" \
  -d '{
    "jsonrpc": "2.0",
    "id": 2,
    "method": "tools/call",
    "params": {
      "name": "getAvailableAppointments",
      "arguments": {
        "specialty_id": 1,
        "limit": 50
      }
    }
  }' | jq '.result.content[0].text | fromjson | {
    message,
    count,
    doctors_with_availability,
    grouped: .grouped_by_doctor_and_specialty | map({
      date,
      doctor: .doctor.name,
      specialty: .specialty.name,
      slots: .total_slots_available,
      availabilities: .availabilities | map({
        id: .availability_id,
        time: .time_range,
        slots: .slots_available
      })
    })
  }'

echo ""
echo ""
echo "=========================================="
echo "PRUEBA 3: Filtrar por médico específico"
echo "Verificar que solo muestra citas de ese médico"
echo "=========================================="

curl -X POST "$API_URL" \
  -H "Content-Type: application/json" \
  -H "Authorization: $TOKEN" \
  -d '{
    "jsonrpc": "2.0",
    "id": 3,
    "method": "tools/call",
    "params": {
      "name": "getAvailableAppointments",
      "arguments": {
        "doctor_id": 1,
        "limit": 50
      }
    }
  }' | jq '.result.content[0].text | fromjson | {
    message,
    count,
    doctors_with_availability,
    grouped: .grouped_by_doctor_and_specialty | map({
      date,
      doctor_id: .doctor.id,
      doctor_name: .doctor.name,
      specialty: .specialty.name,
      total_slots: .total_slots_available,
      morning_and_afternoon: .has_multiple_shifts,
      availabilities: .availabilities | map({
        availability_id,
        time_range,
        slots_available
      })
    })
  }'

echo ""
echo ""
echo "=========================================="
echo "VERIFICACIÓN DE REGLAS:"
echo "=========================================="
echo "✅ 1. Las citas de diferentes médicos están separadas"
echo "✅ 2. Si un médico tiene mañana Y tarde, están agrupadas pero identificables"
echo "✅ 3. Cada availability_id mantiene su identidad única"
echo "✅ 4. Las especialidades se mantienen separadas"
echo "✅ 5. Los cupos disponibles son correctos para cada availability"
echo "=========================================="
