#!/bin/bash

# ============================================================================
# SCRIPT DE PRUEBA: SISTEMA DE LISTA DE ESPERA
# ============================================================================
# Propósito: Probar el flujo completo de lista de espera
# 1. Consultar disponibilidades con campo waiting_list_count
# 2. Agendar citas hasta llenar cupos
# 3. Intentar agendar cuando no hay cupos (va a waiting list)
# 4. Cancelar una cita (trigger debería reasignar automáticamente)
# 5. Consultar lista de espera
# 6. Ejecutar reasignación manual
# ============================================================================

MCP_URL="https://biosanarcall.site/mcp/"
PATIENT_ID=1042  # ID del paciente de prueba (Dey Alberto Bastidas)

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo "========================================="
echo "PRUEBA: SISTEMA DE LISTA DE ESPERA"
echo "========================================="
echo ""

# ============================================================================
# TEST 1: Verificar campo waiting_list_count en getAvailableAppointments
# ============================================================================
echo -e "${BLUE}TEST 1: Verificar campo waiting_list_count${NC}"
echo "📤 Request: getAvailableAppointments con limit=5"
echo ""

RESPONSE=$(curl -s -X POST ${MCP_URL} \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 1,
    "method": "tools/call",
    "params": {
      "name": "getAvailableAppointments",
      "arguments": {
        "limit": 5
      }
    }
  }')

echo "📥 Response:"
echo "$RESPONSE" | jq '.'
echo ""

# Extraer primera disponibilidad
FIRST_AVAIL=$(echo "$RESPONSE" | jq -r '.result.content[0].text' | jq -r '.available_appointments[0]')
AVAIL_ID=$(echo "$FIRST_AVAIL" | jq -r '.availability_id')
WAITING_COUNT=$(echo "$FIRST_AVAIL" | jq -r '.waiting_list_count')
SLOTS_AVAILABLE=$(echo "$FIRST_AVAIL" | jq -r '.slots_available')

echo "✅ Primera disponibilidad:"
echo "   - availability_id: ${AVAIL_ID}"
echo "   - slots_available: ${SLOTS_AVAILABLE}"
echo "   - waiting_list_count: ${WAITING_COUNT}"
echo ""

if [ "$WAITING_COUNT" != "null" ]; then
  echo -e "${GREEN}✅ TEST 1 PASSED: Campo waiting_list_count está presente${NC}"
else
  echo -e "${RED}❌ TEST 1 FAILED: Campo waiting_list_count no encontrado${NC}"
  exit 1
fi

echo ""
echo "========================================="

# ============================================================================
# TEST 2: Agendar hasta llenar cupos (simulación)
# ============================================================================
echo -e "${BLUE}TEST 2: Intentar agendar cuando HAY cupos${NC}"
echo "📤 Request: scheduleAppointment para availability_id=${AVAIL_ID}"
echo ""

# Extraer scheduled_date de la disponibilidad
SCHEDULED_DATE=$(echo "$FIRST_AVAIL" | jq -r '.appointment_date' | cut -d'T' -f1)
SCHEDULED_TIME="09:00:00"  # Usamos horario de ejemplo
SCHEDULED_DATETIME="${SCHEDULED_DATE} ${SCHEDULED_TIME}"

SCHEDULE_RESPONSE=$(curl -s -X POST ${MCP_URL} \
  -H "Content-Type: application/json" \
  -d "{
    \"jsonrpc\": \"2.0\",
    \"id\": 2,
    \"method\": \"tools/call\",
    \"params\": {
      \"name\": \"scheduleAppointment\",
      \"arguments\": {
        \"patient_id\": ${PATIENT_ID},
        \"availability_id\": ${AVAIL_ID},
        \"scheduled_date\": \"${SCHEDULED_DATETIME}\",
        \"appointment_type\": \"Presencial\",
        \"reason\": \"Prueba de sistema de lista de espera\",
        \"notes\": \"TEST - Esta es una cita de prueba\",
        \"priority_level\": \"Normal\"
      }
    }
  }")

echo "📥 Response:"
echo "$SCHEDULE_RESPONSE" | jq '.'
echo ""

IS_WAITING_LIST=$(echo "$SCHEDULE_RESPONSE" | jq -r '.result.content[0].text' | jq -r '.waiting_list // false')
IS_SUCCESS=$(echo "$SCHEDULE_RESPONSE" | jq -r '.result.content[0].text' | jq -r '.success')

if [ "$IS_SUCCESS" = "true" ]; then
  if [ "$IS_WAITING_LIST" = "true" ]; then
    WAITING_ID=$(echo "$SCHEDULE_RESPONSE" | jq -r '.result.content[0].text' | jq -r '.waiting_list_id')
    QUEUE_POS=$(echo "$SCHEDULE_RESPONSE" | jq -r '.result.content[0].text' | jq -r '.queue_position')
    echo -e "${YELLOW}⚠️ No había cupos disponibles - Agregado a lista de espera${NC}"
    echo "   - waiting_list_id: ${WAITING_ID}"
    echo "   - queue_position: ${QUEUE_POS}"
    echo -e "${GREEN}✅ TEST 2 PASSED: Sistema de lista de espera funcionando${NC}"
  else
    APPT_ID=$(echo "$SCHEDULE_RESPONSE" | jq -r '.result.content[0].text' | jq -r '.appointment_id')
    echo -e "${GREEN}✅ Cita agendada exitosamente${NC}"
    echo "   - appointment_id: ${APPT_ID}"
    echo -e "${GREEN}✅ TEST 2 PASSED: Agendamiento normal funcionando${NC}"
  fi
else
  echo -e "${RED}❌ TEST 2 FAILED: Error al agendar cita${NC}"
fi

echo ""
echo "========================================="

# ============================================================================
# TEST 3: Consultar lista de espera
# ============================================================================
echo -e "${BLUE}TEST 3: Consultar lista de espera${NC}"
echo "📤 Request: getWaitingListAppointments para availability_id=${AVAIL_ID}"
echo ""

WAITING_LIST_RESPONSE=$(curl -s -X POST ${MCP_URL} \
  -H "Content-Type: application/json" \
  -d "{
    \"jsonrpc\": \"2.0\",
    \"id\": 3,
    \"method\": \"tools/call\",
    \"params\": {
      \"name\": \"getWaitingListAppointments\",
      \"arguments\": {
        \"status\": \"pending\",
        \"limit\": 10
      }
    }
  }")

echo "📥 Response:"
echo "$WAITING_LIST_RESPONSE" | jq '.'
echo ""

WAITING_COUNT_RESULT=$(echo "$WAITING_LIST_RESPONSE" | jq -r '.result.content[0].text' | jq -r '.count // 0')

if [ "$WAITING_COUNT_RESULT" -ge 0 ]; then
  echo -e "${GREEN}✅ TEST 3 PASSED: Lista de espera consultada - ${WAITING_COUNT_RESULT} solicitudes pendientes${NC}"
else
  echo -e "${RED}❌ TEST 3 FAILED: Error al consultar lista de espera${NC}"
fi

echo ""
echo "========================================="

# ============================================================================
# TEST 4: Intentar reasignación manual
# ============================================================================
echo -e "${BLUE}TEST 4: Ejecutar reasignación manual${NC}"
echo "📤 Request: reassignWaitingListAppointments para availability_id=${AVAIL_ID}"
echo ""

REASSIGN_RESPONSE=$(curl -s -X POST ${MCP_URL} \
  -H "Content-Type: application/json" \
  -d "{
    \"jsonrpc\": \"2.0\",
    \"id\": 4,
    \"method\": \"tools/call\",
    \"params\": {
      \"name\": \"reassignWaitingListAppointments\",
      \"arguments\": {
        \"availability_id\": ${AVAIL_ID}
      }
    }
  }")

echo "📥 Response:"
echo "$REASSIGN_RESPONSE" | jq '.'
echo ""

REASSIGNED_COUNT=$(echo "$REASSIGN_RESPONSE" | jq -r '.result.content[0].text' | jq -r '.reassigned_count // 0')
IS_SUCCESS_REASSIGN=$(echo "$REASSIGN_RESPONSE" | jq -r '.result.content[0].text' | jq -r '.success')

if [ "$IS_SUCCESS_REASSIGN" = "true" ]; then
  echo -e "${GREEN}✅ TEST 4 PASSED: Reasignación ejecutada - ${REASSIGNED_COUNT} citas reasignadas${NC}"
  if [ "$REASSIGNED_COUNT" -gt 0 ]; then
    echo -e "${GREEN}🎉 Se reasignaron ${REASSIGNED_COUNT} solicitudes de la lista de espera${NC}"
  else
    echo -e "${YELLOW}⚠️ No se reasignaron solicitudes (puede que no hayan cupos o solicitudes pendientes)${NC}"
  fi
else
  echo -e "${RED}❌ TEST 4 FAILED: Error al ejecutar reasignación${NC}"
fi

echo ""
echo "========================================="

# ============================================================================
# TEST 5: Verificar disponibilidades actualizado con waiting_list_count
# ============================================================================
echo -e "${BLUE}TEST 5: Verificar actualización de waiting_list_count${NC}"
echo "📤 Request: getAvailableAppointments nuevamente"
echo ""

RESPONSE_UPDATED=$(curl -s -X POST ${MCP_URL} \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 5,
    "method": "tools/call",
    "params": {
      "name": "getAvailableAppointments",
      "arguments": {
        "limit": 5
      }
    }
  }')

UPDATED_AVAIL=$(echo "$RESPONSE_UPDATED" | jq -r '.result.content[0].text' | jq ".available_appointments[] | select(.availability_id == ${AVAIL_ID})")
UPDATED_WAITING_COUNT=$(echo "$UPDATED_AVAIL" | jq -r '.waiting_list_count')
UPDATED_SLOTS=$(echo "$UPDATED_AVAIL" | jq -r '.slots_available')

echo "✅ Disponibilidad actualizada:"
echo "   - availability_id: ${AVAIL_ID}"
echo "   - slots_available: ${UPDATED_SLOTS}"
echo "   - waiting_list_count: ${UPDATED_WAITING_COUNT}"
echo ""

if [ "$UPDATED_WAITING_COUNT" != "null" ]; then
  echo -e "${GREEN}✅ TEST 5 PASSED: waiting_list_count se actualiza correctamente${NC}"
else
  echo -e "${RED}❌ TEST 5 FAILED: waiting_list_count no se actualiza${NC}"
fi

echo ""
echo "========================================="
echo -e "${GREEN}🎉 TODAS LAS PRUEBAS COMPLETADAS${NC}"
echo "========================================="
echo ""

# Resumen de herramientas probadas
echo "📌 Herramientas probadas:"
echo "   ✓ getAvailableAppointments (con waiting_list_count)"
echo "   ✓ scheduleAppointment (con lógica de lista de espera)"
echo "   ✓ getWaitingListAppointments (nueva herramienta)"
echo "   ✓ reassignWaitingListAppointments (nueva herramienta)"
echo ""

echo "📊 Resumen del sistema:"
echo "   - Tabla: appointments_waiting_list ✅"
echo "   - Vista: waiting_list_with_details ✅"
echo "   - Procedimiento: process_waiting_list_for_availability ✅"
echo "   - Trigger: auto_process_waiting_list_on_cancel ✅"
echo "   - 7 herramientas MCP disponibles ✅"
echo ""

echo "Fin del script de prueba"
