#!/bin/bash

echo "=========================================="
echo "TEST: addToWaitingList con specialty_id"
echo "=========================================="
echo ""

echo "📝 Test 1: Agregar paciente 1057 a Cardiología (specialty_id=3)"
echo "Parámetros: patient_id=1057, specialty_id=3, reason='Solicitud de cita de Cardiología'"
echo ""

curl -s http://localhost:8977/mcp-unified -X POST \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 1,
    "method": "tools/call",
    "params": {
      "name": "addToWaitingList",
      "arguments": {
        "patient_id": 1057,
        "specialty_id": 3,
        "reason": "Solicitud de cita de Cardiología"
      }
    }
  }' | jq '.'

echo ""
echo "=========================================="
echo ""

echo "📝 Test 2: Agregar paciente 1058 a Psicología (specialty_id=7)"
echo "Parámetros: patient_id=1058, specialty_id=7, reason='Solicitud de consulta psicológica'"
echo ""

curl -s http://localhost:8977/mcp-unified -X POST \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 2,
    "method": "tools/call",
    "params": {
      "name": "addToWaitingList",
      "arguments": {
        "patient_id": 1058,
        "specialty_id": 7,
        "reason": "Solicitud de consulta psicológica"
      }
    }
  }' | jq '.'

echo ""
echo "=========================================="
echo "✅ TESTS COMPLETADOS"
echo "=========================================="
