#!/bin/bash

echo "================================================"
echo "🧪 TEST: getEPSServices - Servicios por EPS"
echo "================================================"
echo ""

# Test 1: Consultar servicios de NUEVA EPS (id: 14)
echo "📋 Test 1: Servicios autorizados para NUEVA EPS (eps_id: 14)"
echo "Request:"
cat << 'EOF' | jq .
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "tools/call",
  "params": {
    "name": "getEPSServices",
    "arguments": {
      "eps_id": 14
    }
  }
}
EOF

RESPONSE1=$(curl -s -X POST http://localhost:8977/mcp-unified \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 1,
    "method": "tools/call",
    "params": {
      "name": "getEPSServices",
      "arguments": {
        "eps_id": 14
      }
    }
  }')

echo ""
echo "Response (resumen):"
echo "$RESPONSE1" | jq '.result.content[0].text | fromjson | {success, found, eps_name, count, message}'

echo ""
echo "Especialidades disponibles:"
echo "$RESPONSE1" | jq -r '.result.content[0].text | fromjson | .summary.specialties_display'

echo ""
echo "Sedes disponibles:"
echo "$RESPONSE1" | jq -r '.result.content[0].text | fromjson | .summary.locations_display'

echo ""
echo "Lista detallada de servicios:"
echo "$RESPONSE1" | jq '.result.content[0].text | fromjson | .services[] | {specialty: .specialty.name, location: .location.name, copay: .authorization_details.copay_percentage, prior_auth: .authorization_details.requires_prior_authorization}'

echo ""
echo "---"
echo ""

# Test 2: Consultar servicios de FAMISANAR (id: 12)
echo "📋 Test 2: Servicios autorizados para FAMISANAR (eps_id: 12)"
echo "Request:"
cat << 'EOF' | jq .
{
  "jsonrpc": "2.0",
  "id": 2,
  "method": "tools/call",
  "params": {
    "name": "getEPSServices",
    "arguments": {
      "eps_id": 12
    }
  }
}
EOF

RESPONSE2=$(curl -s -X POST http://localhost:8977/mcp-unified \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 2,
    "method": "tools/call",
    "params": {
      "name": "getEPSServices",
      "arguments": {
        "eps_id": 12
      }
    }
  }')

echo ""
echo "Response (resumen):"
echo "$RESPONSE2" | jq '.result.content[0].text | fromjson | {success, found, eps_name, count, message}'

echo ""
echo "Especialidades disponibles:"
echo "$RESPONSE2" | jq -r '.result.content[0].text | fromjson | .summary.specialties_display // "Sin servicios"'

echo ""
echo "---"
echo ""

# Test 3: Error - Sin eps_id
echo "📋 Test 3: Error al no proporcionar eps_id"
echo "Request:"
cat << 'EOF' | jq .
{
  "jsonrpc": "2.0",
  "id": 3,
  "method": "tools/call",
  "params": {
    "name": "getEPSServices",
    "arguments": {}
  }
}
EOF

RESPONSE3=$(curl -s -X POST http://localhost:8977/mcp-unified \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 3,
    "method": "tools/call",
    "params": {
      "name": "getEPSServices",
      "arguments": {}
    }
  }')

echo ""
echo "Response:"
echo "$RESPONSE3" | jq '.result.content[0].text | fromjson | {success, error, usage}'

echo ""
echo "---"
echo ""

# Test 4: EPS inexistente
echo "📋 Test 4: EPS inexistente (eps_id: 9999)"
echo "Request:"
cat << 'EOF' | jq .
{
  "jsonrpc": "2.0",
  "id": 4,
  "method": "tools/call",
  "params": {
    "name": "getEPSServices",
    "arguments": {
      "eps_id": 9999
    }
  }
}
EOF

RESPONSE4=$(curl -s -X POST http://localhost:8977/mcp-unified \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 4,
    "method": "tools/call",
    "params": {
      "name": "getEPSServices",
      "arguments": {
        "eps_id": 9999
      }
    }
  }')

echo ""
echo "Response:"
echo "$RESPONSE4" | jq '.result.content[0].text | fromjson | {success, error, message, suggestion}'

echo ""
echo "---"
echo ""

# Validación de tests
echo "✅ VALIDACIÓN DE TESTS"
echo ""

# Validar Test 1
SUCCESS1=$(echo "$RESPONSE1" | jq -r '.result.content[0].text | fromjson | .success')
FOUND1=$(echo "$RESPONSE1" | jq -r '.result.content[0].text | fromjson | .found')
COUNT1=$(echo "$RESPONSE1" | jq -r '.result.content[0].text | fromjson | .count')
SPECIALTIES1=$(echo "$RESPONSE1" | jq -r '.result.content[0].text | fromjson | .summary.specialties_display')

if [ "$SUCCESS1" == "true" ] && [ "$FOUND1" == "true" ] && [ "$COUNT1" -gt "0" ]; then
  echo "✅ Test 1 PASS: getEPSServices para NUEVA EPS funciona"
  echo "   Servicios encontrados: $COUNT1"
  echo "   Especialidades: $SPECIALTIES1"
else
  echo "❌ Test 1 FAIL: getEPSServices para NUEVA EPS no funcionó correctamente"
fi

echo ""

# Validar Test 2
SUCCESS2=$(echo "$RESPONSE2" | jq -r '.result.content[0].text | fromjson | .success')
if [ "$SUCCESS2" == "true" ]; then
  echo "✅ Test 2 PASS: getEPSServices para FAMISANAR funciona"
else
  echo "❌ Test 2 FAIL: getEPSServices para FAMISANAR no funcionó"
fi

echo ""

# Validar Test 3
ERROR3=$(echo "$RESPONSE3" | jq -r '.result.content[0].text | fromjson | .error')
if [ "$ERROR3" != "null" ] && [ -n "$ERROR3" ]; then
  echo "✅ Test 3 PASS: Validación de eps_id obligatorio funciona"
  echo "   Error: $ERROR3"
else
  echo "❌ Test 3 FAIL: No validó eps_id obligatorio"
fi

echo ""

# Validar Test 4
ERROR4=$(echo "$RESPONSE4" | jq -r '.result.content[0].text | fromjson | .error')
if [ "$ERROR4" != "null" ] && [ -n "$ERROR4" ]; then
  echo "✅ Test 4 PASS: Validación de EPS inexistente funciona"
  echo "   Error: $ERROR4"
else
  echo "❌ Test 4 FAIL: No validó EPS inexistente"
fi

echo ""
echo "================================================"
echo "🎯 EJEMPLO DE USO EN CONVERSACIÓN"
echo "================================================"
echo ""
echo "👤 Paciente: \"Tengo NUEVA EPS, ¿qué especialidades puedo usar?\""
echo ""
echo "🤖 Agente: [Llama a getEPSServices con eps_id=14]"
echo ""
echo "🤖 Agente: \"Con su EPS NUEVA EPS, puede acceder a las siguientes"
echo "           especialidades: $SPECIALTIES1\""
echo ""
echo "================================================"
