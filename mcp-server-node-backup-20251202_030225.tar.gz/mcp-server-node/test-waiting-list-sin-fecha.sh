#!/bin/bash

echo "========================================"
echo "TEST: addToWaitingList SIN scheduled_date"
echo "========================================"
echo ""

# Credenciales desde .env
DB_USER="biosanar_user"
DB_PASS="/6Tx0eXqFQONTFuoc7aqPicNlPhmuINU"
DB_NAME="biosanar"

# Test 1: Agregar a lista de espera SIN fecha programada
echo "📋 Test 1: Agregar paciente a lista de espera sin fecha programada"
echo "---"

curl -s -X POST http://localhost:8977/execute \
  -H "Content-Type: application/json" \
  -u "$DB_USER:$DB_PASS" \
  -d '{
    "tool": "addToWaitingList",
    "arguments": {
      "patient_id": 1,
      "availability_id": 1,
      "appointment_type": "Presencial",
      "reason": "Consulta de control general - fecha flexible",
      "notes": "Paciente puede asistir cualquier día disponible",
      "priority_level": "Normal",
      "requested_by": "Test_Sistema",
      "call_type": "normal"
    }
  }' | jq '.'

echo ""
echo "---"

# Verificar que se insertó con scheduled_date = NULL
echo "📊 Verificando que scheduled_date sea NULL en la base de datos:"
mysql -u "$DB_USER" -p"$DB_PASS" -D "$DB_NAME" -e "
  SELECT 
    id,
    patient_id,
    availability_id,
    scheduled_date,
    appointment_type,
    reason,
    priority_level,
    status,
    created_at
  FROM appointments_waiting_list
  ORDER BY id DESC
  LIMIT 5;
" 2>&1

echo ""
echo "========================================"
echo "Test 2: Agregar con fecha programada (opcional)"
echo "========================================"
echo ""

curl -s -X POST http://localhost:8977/execute \
  -H "Content-Type: application/json" \
  -u "$DB_USER:$DB_PASS" \
  -d '{
    "tool": "addToWaitingList",
    "arguments": {
      "patient_id": 2,
      "availability_id": 2,
      "scheduled_date": "2025-10-20 10:00:00",
      "appointment_type": "Telemedicina",
      "reason": "Consulta especializada - fecha preferida",
      "notes": "Paciente prefiere esta fecha pero acepta otras",
      "priority_level": "Alta",
      "requested_by": "Test_Sistema",
      "call_type": "normal"
    }
  }' | jq '.'

echo ""
echo "---"
echo "📊 Verificando últimos registros:"
mysql -u "$DB_USER" -p"$DB_PASS" -D "$DB_NAME" -e "
  SELECT 
    id,
    patient_id,
    scheduled_date,
    priority_level,
    status,
    created_at
  FROM appointments_waiting_list
  ORDER BY id DESC
  LIMIT 5;
" 2>&1

echo ""
echo "✅ Tests completados"
