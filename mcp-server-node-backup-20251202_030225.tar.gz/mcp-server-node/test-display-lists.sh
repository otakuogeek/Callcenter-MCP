#!/bin/bash

echo "================================================"
echo "🧪 TEST: display_list en listActiveEPS y listZones"
echo "================================================"
echo ""

# Test 1: listActiveEPS con display_list
echo "📋 Test 1: listActiveEPS debe retornar display_list"
echo "Request:"
cat << 'EOF' | jq .
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "tools/call",
  "params": {
    "name": "listActiveEPS",
    "arguments": {}
  }
}
EOF

RESPONSE1=$(curl -s -X POST http://localhost:8977/mcp-unified \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 1,
    "method": "tools/call",
    "params": {
      "name": "listActiveEPS",
      "arguments": {}
    }
  }')

echo ""
echo "Response:"
echo "$RESPONSE1" | jq '.result.content[0].text | fromjson | {success, count, display_list, presentation_note}'

echo ""
echo "Lista completa de EPS (solo nombres):"
echo "$RESPONSE1" | jq -r '.result.content[0].text | fromjson | .display_list'

echo ""
echo "---"
echo ""

# Test 2: listZones con display_list
echo "📋 Test 2: listZones debe retornar display_list"
echo "Request:"
cat << 'EOF' | jq .
{
  "jsonrpc": "2.0",
  "id": 2,
  "method": "tools/call",
  "params": {
    "name": "listZones",
    "arguments": {}
  }
}
EOF

RESPONSE2=$(curl -s -X POST http://localhost:8977/mcp-unified \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 2,
    "method": "tools/call",
    "params": {
      "name": "listZones",
      "arguments": {}
    }
  }')

echo ""
echo "Response:"
echo "$RESPONSE2" | jq '.result.content[0].text | fromjson | {success, count, display_list, presentation_note}'

echo ""
echo "Lista completa de Zonas (solo nombres):"
echo "$RESPONSE2" | jq -r '.result.content[0].text | fromjson | .display_list'

echo ""
echo "---"
echo ""

# Validación de tests
echo "✅ VALIDACIÓN DE TESTS"
echo ""

# Validar que display_list exista en EPS
DISPLAY_LIST_EPS=$(echo "$RESPONSE1" | jq -r '.result.content[0].text | fromjson | .display_list')
if [ -n "$DISPLAY_LIST_EPS" ] && [ "$DISPLAY_LIST_EPS" != "null" ]; then
  echo "✅ Test 1 PASS: listActiveEPS retorna display_list"
  echo "   Valor: '$DISPLAY_LIST_EPS'"
else
  echo "❌ Test 1 FAIL: listActiveEPS NO retorna display_list"
fi

echo ""

# Validar que display_list exista en Zonas
DISPLAY_LIST_ZONES=$(echo "$RESPONSE2" | jq -r '.result.content[0].text | fromjson | .display_list')
if [ -n "$DISPLAY_LIST_ZONES" ] && [ "$DISPLAY_LIST_ZONES" != "null" ]; then
  echo "✅ Test 2 PASS: listZones retorna display_list"
  echo "   Valor: '$DISPLAY_LIST_ZONES'"
else
  echo "❌ Test 2 FAIL: listZones NO retorna display_list"
fi

echo ""
echo "================================================"
echo "🎯 EJEMPLO DE USO EN CONVERSACIÓN"
echo "================================================"
echo ""
echo "🤖 Agente (ANTES - mostraba IDs):"
echo "   \"¿Cuál es su EPS? Tenemos: FAMISANAR (id: 12), NUEVA EPS (id: 8), ...\""
echo ""
echo "🤖 Agente (AHORA - sin IDs, usando display_list):"
echo "   \"¿Cuál es su EPS? Tenemos: $DISPLAY_LIST_EPS\""
echo ""
echo "🤖 Para zonas:"
echo "   \"¿En qué zona se encuentra? Tenemos: $DISPLAY_LIST_ZONES\""
echo ""
echo "================================================"
