#!/bin/bash

API_URL="https://biosanarcall.site/mcp/"

echo "=========================================="
echo "PRUEBA: getAvailableAppointments"
echo "Verificar que retorna agendas incluso SIN cupos"
echo "=========================================="
echo ""

# Test 1: Obtener todas las agendas (con y sin cupos)
echo "TEST 1: Consultar TODAS las agendas disponibles"
echo "Esperado: Debe retornar agendas incluso si slots_available = 0"
echo ""

RESPONSE=$(curl -s -X POST "$API_URL" \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 1,
    "method": "tools/call",
    "params": {
      "name": "getAvailableAppointments",
      "arguments": {}
    }
  }')

echo "$RESPONSE" | jq -r '.result.content[] | select(.text != null) | .text' | jq '{
  success,
  message,
  count,
  doctors_with_availability,
  info: .info.waiting_list_support,
  sample_appointments: [.available_appointments[] | {
    availability_id,
    appointment_date,
    time_range,
    slots_available,
    waiting_list_count,
    doctor: .doctor.name,
    specialty: .specialty.name,
    location: .location.name
  }] | .[0:5]
}'

echo ""
echo "----------------------------------------"
echo ""

# Test 2: Filtrar por especialidad que sabemos tiene cupos llenos
echo "TEST 2: Consultar Dermatología (sabemos que tiene 3 en lista de espera)"
echo "Esperado: Debe retornar la agenda de Dermatología aunque slots_available = 0"
echo ""

RESPONSE2=$(curl -s -X POST "$API_URL" \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 2,
    "method": "tools/call",
    "params": {
      "name": "getAvailableAppointments",
      "arguments": {
        "specialty_id": 10
      }
    }
  }')

echo "$RESPONSE2" | jq -r '.result.content[] | select(.text != null) | .text' | jq '{
  success,
  message,
  count,
  dermatologia_agendas: [.available_appointments[] | {
    availability_id,
    appointment_date,
    time_range,
    slots_available,
    waiting_list_count,
    doctor: .doctor.name,
    can_schedule_direct: (if .slots_available > 0 then "✓ SÍ (cita directa)" else "✗ NO (lista de espera)" end)
  }]
}'

echo ""
echo "----------------------------------------"
echo ""

# Test 3: Verificar estadísticas de agendas con y sin cupos
echo "TEST 3: Estadísticas de cupos"
echo ""

STATS=$(echo "$RESPONSE" | jq -r '.result.content[] | select(.text != null) | .text' | jq '
  .available_appointments | 
  group_by(.slots_available > 0) | 
  map({
    tipo: (if .[0].slots_available > 0 then "Con cupos disponibles" else "Sin cupos (lista espera)" end),
    cantidad: length,
    ejemplo: .[0] | {
      specialty: .specialty.name,
      location: .location.name,
      slots_available,
      waiting_list_count
    }
  })
')

echo "$STATS" | jq '.'

echo ""
echo "=========================================="
echo "RESUMEN"
echo "=========================================="
echo "✓ getAvailableAppointments ahora retorna TODAS las agendas"
echo "✓ Incluye agendas con slots_available = 0"
echo "✓ El prompt puede presentar todas las especialidades"
echo "✓ scheduleAppointment decidirá si es cita directa o lista de espera"
echo ""
