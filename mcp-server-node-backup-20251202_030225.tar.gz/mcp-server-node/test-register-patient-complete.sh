#!/bin/bash

# Test completo del registro de pacientes con campos obligatorios
# Incluye: document, name, phone, birth_date, gender, zone_id, insurance_eps_id

echo "=========================================="
echo "TEST 1: Listar Zonas Disponibles"
echo "=========================================="
curl -s -X POST http://localhost:8977/mcp-unified \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 1,
    "method": "tools/call",
    "params": {
      "name": "listZones",
      "arguments": {}
    }
  }' | jq .

echo -e "\n\n=========================================="
echo "TEST 2: Listar EPS Activas"
echo "=========================================="
curl -s -X POST http://localhost:8977/mcp-unified \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 2,
    "method": "tools/call",
    "params": {
      "name": "listActiveEPS",
      "arguments": {}
    }
  }' | jq .

echo -e "\n\n=========================================="
echo "TEST 3: Registro con Campos Faltantes (DEBE FALLAR)"
echo "=========================================="
curl -s -X POST http://localhost:8977/mcp-unified \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 3,
    "method": "tools/call",
    "params": {
      "name": "registerPatientSimple",
      "arguments": {
        "document": "123456789",
        "name": "Prueba Paciente"
      }
    }
  }' | jq .

echo -e "\n\n=========================================="
echo "TEST 4: Registro con Género Inválido (DEBE FALLAR)"
echo "=========================================="
curl -s -X POST http://localhost:8977/mcp-unified \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 4,
    "method": "tools/call",
    "params": {
      "name": "registerPatientSimple",
      "arguments": {
        "document": "123456789",
        "name": "Prueba Paciente",
        "phone": "3001234567",
        "birth_date": "1990-05-15",
        "gender": "Indefinido",
        "zone_id": 3,
        "insurance_eps_id": 12
      }
    }
  }' | jq .

echo -e "\n\n=========================================="
echo "TEST 5: Registro con Fecha Inválida (DEBE FALLAR)"
echo "=========================================="
curl -s -X POST http://localhost:8977/mcp-unified \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 5,
    "method": "tools/call",
    "params": {
      "name": "registerPatientSimple",
      "arguments": {
        "document": "123456789",
        "name": "Prueba Paciente",
        "phone": "3001234567",
        "birth_date": "15/05/1990",
        "gender": "Masculino",
        "zone_id": 3,
        "insurance_eps_id": 12
      }
    }
  }' | jq .

echo -e "\n\n=========================================="
echo "TEST 6: Registro con Zona Inválida (DEBE FALLAR)"
echo "=========================================="
curl -s -X POST http://localhost:8977/mcp-unified \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 6,
    "method": "tools/call",
    "params": {
      "name": "registerPatientSimple",
      "arguments": {
        "document": "123456789",
        "name": "Prueba Paciente",
        "phone": "3001234567",
        "birth_date": "1990-05-15",
        "gender": "Masculino",
        "zone_id": 999,
        "insurance_eps_id": 12
      }
    }
  }' | jq .

echo -e "\n\n=========================================="
echo "TEST 7: Registro con EPS Inválida (DEBE FALLAR)"
echo "=========================================="
curl -s -X POST http://localhost:8977/mcp-unified \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 7,
    "method": "tools/call",
    "params": {
      "name": "registerPatientSimple",
      "arguments": {
        "document": "123456789",
        "name": "Prueba Paciente",
        "phone": "3001234567",
        "birth_date": "1990-05-15",
        "gender": "Masculino",
        "zone_id": 3,
        "insurance_eps_id": 999
      }
    }
  }' | jq .

echo -e "\n\n=========================================="
echo "TEST 8: Registro COMPLETO y EXITOSO"
echo "=========================================="
RANDOM_DOC="TEST$(date +%s)"
curl -s -X POST http://localhost:8977/mcp-unified \
  -H "Content-Type: application/json" \
  -d "{
    \"jsonrpc\": \"2.0\",
    \"id\": 8,
    \"method\": \"tools/call\",
    \"params\": {
      \"name\": \"registerPatientSimple\",
      \"arguments\": {
        \"document\": \"$RANDOM_DOC\",
        \"name\": \"María José Pérez García\",
        \"phone\": \"3157894561\",
        \"birth_date\": \"1985-03-20\",
        \"gender\": \"Femenino\",
        \"zone_id\": 3,
        \"insurance_eps_id\": 12,
        \"notes\": \"Paciente de prueba - Registro completo con todos los campos obligatorios\"
      }
    }
  }" | jq .

echo -e "\n\n=========================================="
echo "TEST 9: Registro con Otro Género"
echo "=========================================="
RANDOM_DOC2="TEST$(date +%s)B"
curl -s -X POST http://localhost:8977/mcp-unified \
  -H "Content-Type: application/json" \
  -d "{
    \"jsonrpc\": \"2.0\",
    \"id\": 9,
    \"method\": \"tools/call\",
    \"params\": {
      \"name\": \"registerPatientSimple\",
      \"arguments\": {
        \"document\": \"$RANDOM_DOC2\",
        \"name\": \"Alex Rodríguez\",
        \"phone\": \"3001112233\",
        \"birth_date\": \"2000-12-01\",
        \"gender\": \"Otro\",
        \"zone_id\": 4,
        \"insurance_eps_id\": 14,
        \"notes\": \"Paciente con género 'Otro'\"
      }
    }
  }" | jq .

echo -e "\n\n=========================================="
echo "TEST 10: Verificar Schema de registerPatientSimple"
echo "=========================================="
curl -s -X POST http://localhost:8977/mcp-unified \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 10,
    "method": "tools/list"
  }' | jq '.result.tools[] | select(.name == "registerPatientSimple")'

echo -e "\n\n✅ Tests completados!"
