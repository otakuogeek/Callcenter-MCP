#!/bin/bash

echo "======================================================================"
echo "TEST: searchSpecialties - Búsqueda de Especialidades"
echo "======================================================================"
echo ""

# Test 1: Listar todas
echo "📝 TEST 1: Listar TODAS las especialidades"
echo ""
curl -s -X POST http://localhost:8977/mcp-unified \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 1,
    "method": "tools/call",
    "params": {
      "name": "searchSpecialties",
      "arguments": {}
    }
  }' | python3 -c "import sys, json; data=json.load(sys.stdin); result=json.loads(data['result']['content'][0]['text']); print(f\"Total: {result['total']} especialidades\"); [print(f\"  {s['id']:2d}. {s['name']:20s} - Duración: {s['duration_minutes']}min - {'✅ Activa' if s['active'] else '❌ Inactiva'}\") for s in result['specialties']]"

echo ""
echo "======================================================================"
echo ""

# Test 2: Buscar por nombre
echo "📝 TEST 2: Buscar por nombre 'cardio'"
echo ""
curl -s -X POST http://localhost:8977/mcp-unified \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 1,
    "method": "tools/call",
    "params": {
      "name": "searchSpecialties",
      "arguments": {
        "name": "cardio"
      }
    }
  }' | python3 -c "import sys, json; data=json.load(sys.stdin); result=json.loads(data['result']['content'][0]['text']); print(f\"Encontrado: {result['total']} resultado(s)\"); [print(f\"  ID: {s['id']}, Nombre: {s['name']}, Activa: {s['active']}\") for s in result['specialties']]"

echo ""
echo "======================================================================"
echo ""

# Test 3: Buscar por ID
echo "📝 TEST 3: Buscar por ID específico (16 - Neurología)"
echo ""
curl -s -X POST http://localhost:8977/mcp-unified \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 1,
    "method": "tools/call",
    "params": {
      "name": "searchSpecialties",
      "arguments": {
        "specialty_id": 16
      }
    }
  }' | python3 -c "import sys, json; data=json.load(sys.stdin); result=json.loads(data['result']['content'][0]['text']); s=result['specialties'][0]; print(f\"ID: {s['id']}\"); print(f\"Nombre: {s['name']}\"); print(f\"Descripción: {s['description']}\"); print(f\"Duración: {s['duration_minutes']} minutos\"); print(f\"Estado: {'✅ Activa' if s['active'] else '❌ Inactiva'}\")"

echo ""
echo "======================================================================"
echo ""

# Test 4: Solo activas
echo "📝 TEST 4: Solo especialidades ACTIVAS"
echo ""
curl -s -X POST http://localhost:8977/mcp-unified \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 1,
    "method": "tools/call",
    "params": {
      "name": "searchSpecialties",
      "arguments": {
        "active_only": true
      }
    }
  }' | python3 -c "import sys, json; data=json.load(sys.stdin); result=json.loads(data['result']['content'][0]['text']); print(f\"Total activas: {result['total']}\"); print(f\"Criterio: {result['search_criteria']['active_only']}\")"

echo ""
echo "======================================================================"
echo "✅ TESTS COMPLETADOS"
echo "======================================================================"
