#!/bin/bash

# Script de prueba para el endpoint MCP en biosanarcall.site/mcp/

echo "========================================="
echo "PRUEBA DE ENDPOINT MCP - BIOSANARCALL"
echo "========================================="
echo ""

# URL del endpoint
MCP_URL="https://biosanarcall.site/mcp/"

# Colores para output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo "🔍 Endpoint: $MCP_URL"
echo ""

# Test 1: Lista de herramientas disponibles
echo "========================================="
echo "TEST 1: Listar herramientas disponibles"
echo "========================================="

TOOLS_REQUEST='{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "tools/list"
}'

echo "📤 Request:"
echo "$TOOLS_REQUEST" | jq '.'
echo ""

TOOLS_RESPONSE=$(curl -s -X POST "$MCP_URL" \
  -H "Content-Type: application/json" \
  -d "$TOOLS_REQUEST")

echo "📥 Response:"
echo "$TOOLS_RESPONSE" | jq '.'
echo ""

# Verificar si getAvailableAppointments está disponible
if echo "$TOOLS_RESPONSE" | jq -e '.result.tools[] | select(.name == "getAvailableAppointments")' > /dev/null; then
  echo -e "${GREEN}✅ Herramienta getAvailableAppointments encontrada${NC}"
else
  echo -e "${RED}❌ Herramienta getAvailableAppointments NO encontrada${NC}"
  exit 1
fi

echo ""
sleep 2

# Test 2: Consultar citas disponibles (sin filtros)
echo "========================================="
echo "TEST 2: Consultar citas disponibles"
echo "========================================="

APPOINTMENTS_REQUEST='{
  "jsonrpc": "2.0",
  "id": 2,
  "method": "tools/call",
  "params": {
    "name": "getAvailableAppointments",
    "arguments": {
      "limit": 10
    }
  }
}'

echo "📤 Request:"
echo "$APPOINTMENTS_REQUEST" | jq '.'
echo ""

APPOINTMENTS_RESPONSE=$(curl -s -X POST "$MCP_URL" \
  -H "Content-Type: application/json" \
  -d "$APPOINTMENTS_REQUEST")

echo "📥 Response:"
echo "$APPOINTMENTS_RESPONSE" | jq '.'
echo ""

# Verificar si hay agrupación por doctor y especialidad
if echo "$APPOINTMENTS_RESPONSE" | jq -e '.result.content[0].text' > /dev/null; then
  CONTENT=$(echo "$APPOINTMENTS_RESPONSE" | jq -r '.result.content[0].text')
  
  if echo "$CONTENT" | jq -e '.grouped_by_doctor_and_specialty' > /dev/null; then
    echo -e "${GREEN}✅ Agrupación por doctor y especialidad encontrada${NC}"
    
    # Mostrar estadísticas
    GROUPED_COUNT=$(echo "$CONTENT" | jq '.grouped_by_doctor_and_specialty | length')
    TOTAL_COUNT=$(echo "$CONTENT" | jq '.count')
    
    echo ""
    echo -e "${YELLOW}📊 Estadísticas:${NC}"
    echo "  • Total de disponibilidades: $TOTAL_COUNT"
    echo "  • Médicos con disponibilidad: $GROUPED_COUNT"
    echo ""
    
    # Mostrar ejemplos de agrupación
    echo -e "${YELLOW}📋 Ejemplos de agrupación:${NC}"
    echo "$CONTENT" | jq '.grouped_by_doctor_and_specialty[0:3] | .[] | {
      date,
      doctor: .doctor.name,
      specialty: .specialty.name,
      total_slots: .total_slots_available,
      has_morning: .has_morning_slots,
      has_afternoon: .has_afternoon_slots,
      multiple_shifts: .has_multiple_shifts,
      availabilities_count: (.availabilities | length)
    }'
    
  else
    echo -e "${RED}❌ Agrupación por doctor y especialidad NO encontrada${NC}"
  fi
else
  echo -e "${RED}❌ Respuesta inválida${NC}"
  exit 1
fi

echo ""
echo "========================================="
echo "TEST 3: Consultar por especialidad"
echo "========================================="

SPECIALTY_REQUEST='{
  "jsonrpc": "2.0",
  "id": 3,
  "method": "tools/call",
  "params": {
    "name": "getAvailableAppointments",
    "arguments": {
      "specialty_id": 1,
      "limit": 5
    }
  }
}'

echo "📤 Request (specialty_id=1):"
echo "$SPECIALTY_REQUEST" | jq '.'
echo ""

SPECIALTY_RESPONSE=$(curl -s -X POST "$MCP_URL" \
  -H "Content-Type: application/json" \
  -d "$SPECIALTY_REQUEST")

echo "📥 Response:"
echo "$SPECIALTY_RESPONSE" | jq '.result.content[0].text | fromjson | {
  success,
  message,
  count,
  doctors_with_availability,
  filters_applied
}'

echo ""
echo "========================================="
echo -e "${GREEN}✅ TODAS LAS PRUEBAS COMPLETADAS${NC}"
echo "========================================="
echo ""
echo "📌 Reglas de agrupación verificadas:"
echo "   ✓ Las citas se agrupan SOLO por mismo médico + especialidad"
echo "   ✓ NO se mezclan citas de diferentes médicos"
echo "   ✓ Si un médico tiene mañana Y tarde, se identifican claramente"
echo ""
