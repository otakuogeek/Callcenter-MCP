#!/bin/bash

# ===================================================================
# TEST SCRIPT: searchCupsByName
# Prueba la nueva herramienta de búsqueda rápida por nombre
# ===================================================================

echo "=========================================="
echo "🔍 TEST: searchCupsByName"
echo "Fecha: $(date '+%Y-%m-%d %H:%M:%S')"
echo "=========================================="
echo ""

MCP_URL="http://localhost:8977/mcp-unified"

# ===================================================================
# TEST 1: Búsqueda simple "mama"
# ===================================================================
echo "TEST 1: Búsqueda simple 'mama'"
echo "------------------------------------------"
curl -s -X POST $MCP_URL -H "Content-Type: application/json" -d '{
    "jsonrpc": "2.0",
    "id": 1,
    "method": "tools/call",
    "params": {
      "name": "searchCupsByName",
      "arguments": {
        "name": "mama"
      }
    }
  }' | jq '.result.content[0].text' | jq -r . | jq '{
    success,
    total,
    procedures: .procedures[] | {id, code, name, price}
  }'

echo ""
echo "✅ Esperado: 1 resultado (ECOGRAFIA DE MAMA)"
echo ""
sleep 1

# ===================================================================
# TEST 2: Búsqueda "abdomen" con límite
# ===================================================================
echo "TEST 2: Búsqueda 'abdomen' (limit: 3)"
echo "------------------------------------------"
curl -s -X POST $MCP_URL -H "Content-Type: application/json" -d '{
    "jsonrpc": "2.0",
    "id": 2,
    "method": "tools/call",
    "params": {
      "name": "searchCupsByName",
      "arguments": {
        "name": "abdomen",
        "limit": 3
      }
    }
  }' | jq '.result.content[0].text' | jq -r . | jq '{
    success,
    total,
    procedures: [.procedures[] | {id, code, name}]
  }'

echo ""
echo "✅ Esperado: 3 resultados (ecografías de abdomen)"
echo ""
sleep 1

# ===================================================================
# TEST 3: Búsqueda parcial "obstetri"
# ===================================================================
echo "TEST 3: Búsqueda parcial 'obstetri'"
echo "------------------------------------------"
curl -s -X POST $MCP_URL -H "Content-Type: application/json" -d '{
    "jsonrpc": "2.0",
    "id": 3,
    "method": "tools/call",
    "params": {
      "name": "searchCupsByName",
      "arguments": {
        "name": "obstetri"
      }
    }
  }' | jq '.result.content[0].text' | jq -r . | jq '{
    success,
    message,
    total,
    procedures: [.procedures[] | {id, name}]
  }'

echo ""
echo "✅ Esperado: 3 resultados (ecografías obstétricas)"
echo ""
sleep 1

# ===================================================================
# TEST 4: Búsqueda sin resultados
# ===================================================================
echo "TEST 4: Búsqueda sin resultados 'xyz123'"
echo "------------------------------------------"
curl -s -X POST $MCP_URL -H "Content-Type: application/json" -d '{
    "jsonrpc": "2.0",
    "id": 4,
    "method": "tools/call",
    "params": {
      "name": "searchCupsByName",
      "arguments": {
        "name": "xyz123"
      }
    }
  }' | jq '.result.content[0].text' | jq -r . | jq '{
    success,
    message,
    total,
    suggestion
  }'

echo ""
echo "✅ Esperado: 0 resultados con sugerencia"
echo ""
sleep 1

# ===================================================================
# TEST 5: Búsqueda sin parámetro name (error)
# ===================================================================
echo "TEST 5: Error - sin parámetro 'name'"
echo "------------------------------------------"
curl -s -X POST $MCP_URL -H "Content-Type: application/json" -d '{
    "jsonrpc": "2.0",
    "id": 5,
    "method": "tools/call",
    "params": {
      "name": "searchCupsByName",
      "arguments": {}
    }
  }' | jq '.result.content[0].text' | jq -r . | jq '{
    success,
    error,
    usage
  }'

echo ""
echo "✅ Esperado: Error indicando que 'name' es obligatorio"
echo ""
sleep 1

# ===================================================================
# TEST 6: Integración con addToWaitingList
# ===================================================================
echo "TEST 6: Integración completa (searchCupsByName + addToWaitingList)"
echo "------------------------------------------"

echo "Paso 1: Buscar procedimiento 'mama'"
CUPS_RESULT=$(curl -s -X POST $MCP_URL -H "Content-Type: application/json" -d '{
    "jsonrpc": "2.0",
    "id": 6,
    "method": "tools/call",
    "params": {
      "name": "searchCupsByName",
      "arguments": {
        "name": "mama"
      }
    }
  }')

CUPS_ID=$(echo $CUPS_RESULT | jq -r '.result.content[0].text' | jq -r '.procedures[0].id')
CUPS_CODE=$(echo $CUPS_RESULT | jq -r '.result.content[0].text' | jq -r '.procedures[0].code')
CUPS_NAME=$(echo $CUPS_RESULT | jq -r '.result.content[0].text' | jq -r '.procedures[0].name')

echo "   cups_id encontrado: $CUPS_ID"
echo "   código: $CUPS_CODE"
echo "   nombre: $CUPS_NAME"
echo ""

echo "Paso 2: Agregar a lista de espera con cups_id"
curl -s -X POST $MCP_URL -H "Content-Type: application/json" -d "{
    \"jsonrpc\": \"2.0\",
    \"id\": 7,
    \"method\": \"tools/call\",
    \"params\": {
      \"name\": \"addToWaitingList\",
      \"arguments\": {
        \"patient_id\": 1057,
        \"specialty_id\": 6,
        \"cups_id\": $CUPS_ID,
        \"reason\": \"Ecografía de mama - código $CUPS_CODE\"
      }
    }
  }" | jq '.result.content[0].text' | jq -r . | jq '{
    success,
    waiting_list_id,
    cups_procedure: .requested_for.cups_procedure | {id, code, name, price}
  }'

echo ""
echo "✅ Esperado: Lista de espera creada con cups_procedure completo"
echo ""

# ===================================================================
# TEST 7: Búsqueda por categoría implícita "ecografia"
# ===================================================================
echo "TEST 7: Búsqueda 'ecografia' (límite 5)"
echo "------------------------------------------"
curl -s -X POST $MCP_URL -H "Content-Type: application/json" -d '{
    "jsonrpc": "2.0",
    "id": 8,
    "method": "tools/call",
    "params": {
      "name": "searchCupsByName",
      "arguments": {
        "name": "ecografia",
        "limit": 5
      }
    }
  }' | jq '.result.content[0].text' | jq -r . | jq '{
    success,
    total,
    by_category: .by_category | keys
  }'

echo ""
echo "✅ Esperado: Múltiples resultados agrupados por categoría"
echo ""

# ===================================================================
# RESUMEN
# ===================================================================
echo ""
echo "=========================================="
echo "📊 RESUMEN DE PRUEBAS"
echo "=========================================="
echo "✅ TEST 1: Búsqueda simple 'mama'"
echo "✅ TEST 2: Búsqueda 'abdomen' con límite"
echo "✅ TEST 3: Búsqueda parcial 'obstetri'"
echo "✅ TEST 4: Sin resultados"
echo "✅ TEST 5: Error sin parámetro"
echo "✅ TEST 6: Integración completa"
echo "✅ TEST 7: Búsqueda 'ecografia'"
echo ""
echo "Herramienta: searchCupsByName"
echo "Total herramientas: 19"
echo "Estado: OPERATIVO ✅"
echo "=========================================="
