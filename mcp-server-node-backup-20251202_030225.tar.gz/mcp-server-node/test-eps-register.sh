#!/bin/bash

echo "🏥 Test Completo: Consulta de EPS y Registro de Pacientes"
echo "========================================================="

MCP_URL="https://biosanarcall.site/mcp/"

echo ""
echo "1. 📋 Listar Herramientas Disponibles"
echo "--------------------------------------"
curl -s -X POST "$MCP_URL" \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}' | \
  jq -r '.result.tools[] | "✅ " + .name + "\n   📝 " + .description'

echo ""
echo "2. 🏥 Consultar EPS Activas Disponibles"
echo "---------------------------------------"
EPS_RESPONSE=$(curl -s -X POST "$MCP_URL" \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","id":2,"method":"tools/call","params":{"name":"listActiveEPS","arguments":{}}}')

echo "$EPS_RESPONSE" | jq -r '.result.content[0].text | fromjson | 
  "📊 Total de EPS activas: " + (.count | tostring) + "\n"'

echo "EPS Disponibles para Registro:"
echo "$EPS_RESPONSE" | jq -r '.result.content[0].text | fromjson | 
  .eps_list[] | "  🏥 ID: \(.id) - \(.name) (Código: \(.code))"'

echo ""
echo "3. 👤 Registrar Paciente de Ejemplo"
echo "------------------------------------"
RANDOM_NUM=$((10000 + RANDOM % 90000))
REGISTER_RESPONSE=$(curl -s -X POST "$MCP_URL" \
  -H "Content-Type: application/json" \
  -d "{
    \"jsonrpc\":\"2.0\",
    \"id\":3,
    \"method\":\"tools/call\",
    \"params\":{
      \"name\":\"registerPatientSimple\",
      \"arguments\":{
        \"document\":\"TEST$RANDOM_NUM\",
        \"name\":\"Paciente Prueba MCP\",
        \"phone\":\"310$RANDOM_NUM\",
        \"insurance_eps_id\":14,
        \"notes\":\"Registro de prueba con EPS real\"
      }
    }
  }")

echo "$REGISTER_RESPONSE" | jq -r '.result.content[0].text | fromjson | 
  if .success then 
    "✅ PACIENTE REGISTRADO EXITOSAMENTE\n" +
    "   🆔 ID: " + (.patient_id | tostring) + "\n" +
    "   👤 Nombre: " + .patient.name + "\n" +
    "   📄 Documento: " + .patient.document + "\n" +
    "   📞 Teléfono: " + .patient.phone + "\n" +
    "   🏥 EPS: " + .patient.eps + " (Código: " + .patient.eps_code + ")\n" +
    "   ✓ Estado: " + .patient.status
  else 
    "❌ ERROR: " + .error
  end'

echo ""
echo "4. 🔍 Verificar en Base de Datos"
echo "---------------------------------"
mysql -u biosanar_user -pBiosanar2024! biosanar -e "
  SELECT 
    p.id,
    p.document,
    p.name,
    p.phone,
    e.name as eps,
    e.code as eps_code,
    p.status,
    DATE_FORMAT(p.created_at, '%Y-%m-%d %H:%i') as created
  FROM patients p
  LEFT JOIN eps e ON p.insurance_eps_id = e.id
  WHERE p.document LIKE 'TEST%'
  ORDER BY p.id DESC
  LIMIT 5
" 2>/dev/null

echo ""
echo "📊 RESUMEN DEL SISTEMA"
echo "======================"
echo "✅ Herramientas MCP: 2"
echo "   1. listActiveEPS - Consulta de EPS activas"
echo "   2. registerPatientSimple - Registro simplificado"
echo ""
echo "✅ Endpoint principal: $MCP_URL"
echo "✅ Protocolo: JSON-RPC 2.0"
echo "✅ Base de datos: MySQL biosanar"
echo ""
echo "📋 Flujo de Trabajo Recomendado:"
echo "   1. Llamar listActiveEPS para obtener IDs de EPS"
echo "   2. Usar el ID correcto en registerPatientSimple"
echo "   3. Verificar respuesta con datos del paciente creado"
echo ""
