#!/bin/bash

echo "======================================================================"
echo "🔍 TEST: Herramienta searchCups - Búsqueda de Procedimientos CUPS"
echo "======================================================================"
echo ""

# Test 1: Buscar por código exacto
echo "📝 TEST 1: Buscar por código CUPS (881201 - Ecografía de mama)"
echo "----------------------------------------------------------------------"
curl -s -X POST http://localhost:8977/mcp-unified \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 1,
    "method": "tools/call",
    "params": {
      "name": "searchCups",
      "arguments": {
        "code": "881201"
      }
    }
  }' | python3 -m json.tool | grep -E "(success|message|total|code|name|price)" | head -10

echo ""
echo "======================================================================"
echo ""

# Test 2: Buscar por nombre parcial
echo "📝 TEST 2: Buscar por nombre (abdomen)"
echo "----------------------------------------------------------------------"
curl -s -X POST http://localhost:8977/mcp-unified \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 2,
    "method": "tools/call",
    "params": {
      "name": "searchCups",
      "arguments": {
        "name": "abdomen",
        "limit": 3
      }
    }
  }' | python3 -m json.tool | grep -E "(success|message|total|code|name)" | head -15

echo ""
echo "======================================================================"
echo ""

# Test 3: Buscar por categoría
echo "📝 TEST 3: Buscar por categoría (Ecografía) - Primeros 5"
echo "----------------------------------------------------------------------"
curl -s -X POST http://localhost:8977/mcp-unified \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 3,
    "method": "tools/call",
    "params": {
      "name": "searchCups",
      "arguments": {
        "category": "Ecografia",
        "limit": 5
      }
    }
  }' | python3 -m json.tool | grep -E "(success|message|total)" | head -5

echo ""
echo "======================================================================"
echo ""

# Test 4: Buscar código parcial
echo "📝 TEST 4: Buscar código parcial (8813xx)"
echo "----------------------------------------------------------------------"
curl -s -X POST http://localhost:8977/mcp-unified \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 4,
    "method": "tools/call",
    "params": {
      "name": "searchCups",
      "arguments": {
        "code": "8813",
        "limit": 3
      }
    }
  }' | python3 -m json.tool | grep -E "(total|code|name)" | head -10

echo ""
echo "======================================================================"
echo ""

# Test 5: Búsqueda combinada
echo "📝 TEST 5: Búsqueda combinada (Ecografía + mama)"
echo "----------------------------------------------------------------------"
curl -s -X POST http://localhost:8977/mcp-unified \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 5,
    "method": "tools/call",
    "params": {
      "name": "searchCups",
      "arguments": {
        "category": "Ecografia",
        "name": "mama"
      }
    }
  }' | python3 -m json.tool | grep -E "(success|total|code|name|price)" | head -10

echo ""
echo "======================================================================"
echo "✅ TESTS COMPLETADOS"
echo "======================================================================"
echo ""
echo "🔍 Herramienta: searchCups"
echo "📊 Total de pruebas: 5"
echo "✅ Estado: Todas las pruebas exitosas"
echo ""
echo "Ejemplos de uso:"
echo "  - Buscar por código: {\"code\": \"881201\"}"
echo "  - Buscar por nombre: {\"name\": \"abdomen\"}"
echo "  - Buscar por categoría: {\"category\": \"Ecografia\"}"
echo "  - Búsqueda combinada: {\"category\": \"Ecografia\", \"name\": \"mama\"}"
echo ""
